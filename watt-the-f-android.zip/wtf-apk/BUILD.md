# Watt the f* — bygg en Android-APK

Spelet är inbakat i ett Capacitor-projekt som lägger det i en WebView. Här är tre
sätt att få en installerbar APK — välj det som passar dig.

> Förhandskrav för alla lokala vägar: **Node.js** (npm) installerat. Kör en gång:
> ```bash
> npm install
> ```

---

## Väg 1 — Bygg i molnet med GitHub Actions (enklast, inget att installera)

1. Skapa ett nytt GitHub-repo och pusha hela den här mappen till det.
2. Gå till fliken **Actions** i repot. Arbetsflödet "Bygg APK" kör automatiskt vid
   push (eller starta det manuellt med **Run workflow**).
3. När bygget är klart: öppna körningen, ladda ner artefakten
   **watt-the-f-debug-apk**, packa upp och du har `app-debug.apk`.
4. Skicka APK:n till telefonen och installera (tillåt "okända källor").

Allt sker på GitHubs servrar — du behöver inte Android SDK eller Android Studio lokalt.

---

## Väg 2 — Bygg lokalt med Gradle (kräver Android SDK)

```bash
npm install
npx cap sync android
cd android
./gradlew assembleDebug
```

APK:n hamnar i:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

Saknar du Android SDK? Sätt `ANDROID_HOME` till en SDK-installation, eller använd
Android Studio (väg 3) som installerar allt åt dig.

---

## Väg 3 — Android Studio (mest klick-och-kör)

```bash
npm install
npx cap open android      # öppnar projektet i Android Studio
```

Tryck på **Run ▶** med en ansluten telefon eller emulator, så byggs och installeras
spelet direkt. Eller välj **Build → Build APK(s)** för en fristående APK.

---

## Uppdatera spelet senare

Webbkoden ligger i `www/`. Efter ändringar:
```bash
npx cap copy android      # kopierar www/ → android/app/src/main/assets/public
```
Bygg sedan om enligt valfri väg ovan.

---

## Snabbtest utan APK (om du bara vill prova direkt)

Eftersom spelet är ren webb kan du också köra det på telefonen via webbläsaren:
starta en lokal server på datorn (`python3 -m http.server` i spelmappen), öppna
datorns IP i telefonens Chrome, och välj **Lägg till på startskärmen** för en
appliknande genväg. Ljud och sparfunktion fungerar.

---

## Detaljer
- App-id: `com.wattthef.game`, namn: "Watt the f*", liggande läge.
- Debug-APK:n är självsignerad med Androids debug-nyckel och installerbar direkt
  (kräver "tillåt okända källor"). För Play Store krävs en release-signerad APK/AAB.
- WebView har DOM-storage på, så spelets localStorage-sparfunktion fungerar.
