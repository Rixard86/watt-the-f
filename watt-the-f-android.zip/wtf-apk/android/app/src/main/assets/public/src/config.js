/* =========================================================================
   KRAFTNÄTET — speldata
   Effekt i W, kostnad i kr, längd i celler, energi i Ws, forskning i FP.
   ========================================================================= */

const DAY_LENGTH = 18;
const RESEARCH_RATE = 0.08;   // forskningspoäng per (W·s) levererad till labb

const PLANTS = {
  sol:       { name: 'Solpark',     output: 120,  cost: 90,   variable: 'sol',  color: '#f5c542' },
  vind:      { name: 'Vindkraft',   output: 150,  cost: 130,  variable: 'vind', color: '#a8d8ff' },
  ved:       { name: 'Vedkraft',    output: 120,  cost: 160,  variable: null,   color: '#b5793a' },
  kol:       { name: 'Kolkraft',    output: 220,  cost: 240,  variable: null,   color: '#5a5a5a' },
  gas:       { name: 'Gaskraft',    output: 300,  cost: 320,  variable: null,   color: '#ff8c42' },
  karnkraft: { name: 'Kärnkraft',   output: 650,  cost: 900,  variable: null,   color: '#42f5a1' },
  fusion:    { name: 'Fusion',      output: 1300, cost: 2000, variable: null,   color: '#c77dff' },
};

function plantInstantOutput(key, simTime, seed, biome) {
  const p = PLANTS[key];
  const b = BIOMES[biome] || {};
  if (p.variable === 'sol') {
    return p.output * (b.solarMult || 1) * Math.max(0, Math.sin((simTime / DAY_LENGTH) * 2 * Math.PI));
  }
  if (p.variable === 'vind') {
    const s = seed * 1.7;
    const v = 0.55 + 0.30 * Math.sin(simTime * 0.8 + s) + 0.15 * Math.sin(simTime * 2.3 + s * 2.1);
    return p.output * (b.windMult || 1) * Math.min(1, Math.max(0.05, v));
  }
  return p.output;
}

const TOWERS = {
  tra:      { name: 'Trä',      capacity: 150,  span: 3, bundle: 1, cost: 20,  color: '#9c6b3f' },
  betong:   { name: 'Betong',   capacity: 350,  span: 4, bundle: 2, cost: 45,  color: '#9aa0a8' },
  komposit: { name: 'Komposit', capacity: 700,  span: 5, bundle: 2, cost: 90,  color: '#4ad6c4' },
  stal:     { name: 'Stål',     capacity: 1500, span: 6, bundle: 3, cost: 160, color: '#c0c8d4' },
};

// loss = förlustfraktion per cell. Ordning: koppar < aluminium < acsr < järn.
const LINES = {
  jarn:      { name: 'Järn',          capacity: 100, maxLen: 3, cost: 5,  loss: 0.035, color: '#7a6a5a' },
  koppar:    { name: 'Koppar',        capacity: 250, maxLen: 4, cost: 12, loss: 0.005, color: '#c87f4a' },
  aluminium: { name: 'Aluminium',     capacity: 450, maxLen: 5, cost: 20, loss: 0.012, color: '#bcc4cc' },
  acsr:      { name: 'Stålförst. Al', capacity: 900, maxLen: 7, cost: 40, loss: 0.020, color: '#8fa0b5' },
};

const BATTERIES = {
  liion: { name: 'Li-jon lager',      capacity: 1800, chargeRate: 150, dischargeRate: 150, cap: 300, span: 4, cost: 220, color: '#5ad1ff' },
  flow:  { name: 'Storskaligt lager', capacity: 6000, chargeRate: 400, dischargeRate: 400, cap: 700, span: 5, cost: 600, color: '#3a8fff' },
};

// Forskningsanläggningar: drar el (demand) och genererar forskning ur mottagen effekt.
const LABS = {
  lab1: { name: 'Forskningslabb',  demand: 80,  cap: 200, span: 4, cost: 150, color: '#b98cff' },
  lab2: { name: 'Avancerat labb',  demand: 220, cap: 450, span: 5, cost: 500, color: '#d36bff' },
};

// Buntade ledare: fler ledare per fas → mer kapacitet och lägre förlust.
// Begränsas av tornets klass (trä=1, betong/komposit=2, stål=3). Duplex/triplex forskas fram.
const BUNDLES = {
  simplex: { name: 'Simplex', mult: 1 },
  duplex:  { name: 'Duplex',  mult: 2 },
  triplex: { name: 'Triplex', mult: 3 },
};

// Biomer: ger varje bana visuell identitet + milda mekaniska modifierare på sol/vind/förlust.
const BIOMES = {
  lovskog: { name: 'Lövskog', emoji: '🌳', solarMult: 1.0,  windMult: 1.0,  lossMult: 1.0,
    cell: '#121a14', build: '#10241a', station: '#1a1422', mtnBase: '#2a3326', mtnPeak: '#46543c',
    label: 'rgba(110,210,150,0.5)',  near: 'rgba(232,176,86,0.10)', pad: '#1d2a22', night: [8,16,22],  stars: false },
  oken:    { name: 'Öken',    emoji: '🏜️', solarMult: 1.25, windMult: 0.85, lossMult: 1.0,
    cell: '#211c12', build: '#22290f', station: '#241a14', mtnBase: '#3a2f1c', mtnPeak: '#7a6334',
    label: 'rgba(235,205,120,0.55)', near: 'rgba(240,200,110,0.12)', pad: '#2a2414', night: [22,18,28], stars: false },
  vinter:  { name: 'Vinter',  emoji: '❄️', solarMult: 0.7,  windMult: 1.25, lossMult: 0.92,
    cell: '#161d28', build: '#152a26', station: '#1d1730', mtnBase: '#33404f', mtnPeak: '#e6eef7',
    label: 'rgba(150,205,235,0.55)', near: 'rgba(200,220,240,0.12)', pad: '#1b2630', night: [12,20,40], stars: false },
  trask:   { name: 'Träsk',   emoji: '🐸', solarMult: 0.85, windMult: 0.95, lossMult: 1.15,
    cell: '#101a16', build: '#11261c', station: '#161422', mtnBase: '#243026', mtnPeak: '#46583e',
    label: 'rgba(120,200,150,0.5)',  near: 'rgba(150,200,120,0.12)', pad: '#162018', night: [8,18,18],  stars: false },
  rymd:    { name: 'Rymd',    emoji: '🚀', solarMult: 1.4,  windMult: 0.1,  lossMult: 0.85,
    cell: '#0a0a16', build: '#101a26', station: '#1a1230', mtnBase: '#26262e', mtnPeak: '#50505e',
    label: 'rgba(180,170,255,0.55)', near: 'rgba(180,160,255,0.12)', pad: '#141426', night: [4,4,14],   stars: true },
};
const bundleMultByKey = (key) => (BUNDLES[key] ? BUNDLES[key].mult : 1);

// Effektiv kapacitet = lägsta av (linans kapacitet × bunt) och båda tornens kapacitet.
function segmentCapacity(lineKey, capA, capB, bundleMult) {
  return Math.min(LINES[lineKey].capacity * (bundleMult || 1), capA, capB);
}

// --- Teknologiträd (förgrenat, KSP-likt) ---
// tier = kolumn, row = radposition, prereqs = nod-id som krävs, unlocks = recept.
const TECH_TREE = [
  { id: 'start',     name: 'Grundnät',          cost: 0,    tier: 0, row: 1.5, prereqs: [],                         unlocks: [] },

  { id: 'koppar',    name: 'Kopparledningar',   cost: 40,   tier: 1, row: 0,   prereqs: ['start'],                  unlocks: [{ type: 'line', key: 'koppar' }] },
  { id: 'betong',    name: 'Betongtorn',        cost: 60,   tier: 1, row: 1,   prereqs: ['start'],                  unlocks: [{ type: 'tower', key: 'betong' }] },
  { id: 'vind',      name: 'Vindkraft',         cost: 80,   tier: 1, row: 2,   prereqs: ['start'],                  unlocks: [{ type: 'plant', key: 'vind' }] },
  { id: 'liion',     name: 'Li-jon lager',      cost: 100,  tier: 1, row: 3,   prereqs: ['start'],                  unlocks: [{ type: 'battery', key: 'liion' }] },

  { id: 'aluminium', name: 'Aluminiumlinor',    cost: 120,  tier: 2, row: 0,   prereqs: ['koppar'],                 unlocks: [{ type: 'line', key: 'aluminium' }] },
  { id: 'komposit',  name: 'Kompositorn',       cost: 180,  tier: 2, row: 1,   prereqs: ['betong'],                 unlocks: [{ type: 'tower', key: 'komposit' }] },
  { id: 'gas',       name: 'Gaskraft',          cost: 200,  tier: 2, row: 2,   prereqs: ['vind'],                   unlocks: [{ type: 'plant', key: 'gas' }] },
  { id: 'lab2',      name: 'Avancerat labb',    cost: 300,  tier: 2, row: 3,   prereqs: ['koppar', 'betong'],       unlocks: [{ type: 'lab', key: 'lab2' }] },

  { id: 'acsr',      name: 'ACSR-linor',        cost: 300,  tier: 3, row: 0,   prereqs: ['aluminium'],              unlocks: [{ type: 'line', key: 'acsr' }] },
  { id: 'stal',      name: 'Ståltorn',          cost: 450,  tier: 3, row: 1,   prereqs: ['komposit'],               unlocks: [{ type: 'tower', key: 'stal' }] },
  { id: 'karnkraft', name: 'Kärnkraft',         cost: 600,  tier: 3, row: 2,   prereqs: ['gas', 'komposit'],        unlocks: [{ type: 'plant', key: 'karnkraft' }] },
  { id: 'flowbatt',  name: 'Storskaligt lager', cost: 700,  tier: 3, row: 3,   prereqs: ['liion', 'lab2'],          unlocks: [{ type: 'battery', key: 'flow' }] },

  { id: 'duplex',    name: 'Duplexledare',      cost: 160,  tier: 2, row: 4,   prereqs: ['betong'],                 unlocks: [{ type: 'bundle', key: 'duplex' }] },
  { id: 'triplex',   name: 'Triplexledare',     cost: 480,  tier: 3, row: 4,   prereqs: ['stal', 'duplex'],         unlocks: [{ type: 'bundle', key: 'triplex' }] },

  { id: 'fusion',    name: 'Fusion',            cost: 1200, tier: 4, row: 2,   prereqs: ['karnkraft', 'stal', 'acsr'], unlocks: [{ type: 'plant', key: 'fusion' }] },
];

// Recept som är upplåsta från start.
const STARTING_UNLOCKS = {
  plant: ['sol', 'ved', 'kol'],
  tower: ['tra'],
  line: ['jarn'],
  battery: [],
  lab: ['lab1'],
  bundle: ['simplex'],
};

// --- Scenarier ---
const SCENARIOS = [
  {
    id: 1,
    name: 'Första linjen', biome: 'lovskog',
    brief: 'Dra en kort ledning. Järn räcker här men tappar effekt — bygg ett labb och forska fram koppar för längre nät.',
    cols: 8, rows: 7, buildCols: 3,
    startMoney: 450, incomeRate: 0.10, requiredSustain: 5,
    stations: [{ row: 3, demand: 100 }],
    blocked: [],
    target: 72,
  },
  {
    id: 2,
    name: 'Förgrening', biome: 'oken',
    brief: 'Två fabriker över längre avstånd. Järn förlorar för mycket — koppar lönar sig. Tjäna och forska vidare.',
    cols: 12, rows: 9, buildCols: 3,
    startMoney: 750, incomeRate: 0.10, requiredSustain: 6,
    stations: [{ row: 2, demand: 150 }, { row: 6, demand: 150 }],
    blocked: [],
    target: 235,
  },
  {
    id: 3,
    name: 'Bergspasset', biome: 'vinter',
    brief: 'Berg tvingar långa omvägar med stora förluster. Forska fram aluminium/ACSR och starka torn.',
    cols: 15, rows: 10, buildCols: 3,
    startMoney: 1100, incomeRate: 0.12, requiredSustain: 6,
    stations: [{ row: 2, demand: 250 }, { row: 7, demand: 300 }],
    blocked: (() => { const b=[]; for (let r=3;r<=6;r++) for (let c=7;c<=9;c++) b.push({row:r,col:c}); return b; })(),
    target: 430,
  },
  {
    id: 4,
    name: 'Stamnätet', biome: 'trask',
    brief: 'Riksnät över långa avstånd. Bara ACSR/stål håller förlusterna nere. Lager jämnar ut sol och vind.',
    cols: 18, rows: 11, buildCols: 4,
    startMoney: 1500, incomeRate: 0.14, requiredSustain: 7,
    stations: [{ row: 1, demand: 300 }, { row: 5, demand: 450 }, { row: 9, demand: 350 }],
    blocked: (() => {
      const b=[];
      for (let r=2;r<=4;r++) for (let c=8;c<=9;c++) b.push({row:r,col:c});
      for (let r=6;r<=8;r++) for (let c=11;c<=12;c++) b.push({row:r,col:c});
      return b;
    })(),
    target: 850,
  },
  {
    id: 5,
    name: 'Genom bygderna', biome: 'rymd',
    brief: 'Ett långt nät som slingrar förbi samhällen och bergskedjor — dra i sidled för att se hela kartan. Intill ett samhälle får bara trä-/betongtorn och järn-/kopparlinor stå; vill du köra högre tier krävs minst en rutas mellanrum. Bergen tvingar in dig i smala pass, ibland tätt intill husen. Planera vägen noga.',
    cols: 30, rows: 11, buildCols: 4, scroll: true, viewCols: 14,
    startMoney: 2600, incomeRate: 0.14, requiredSustain: 7,
    stations: [{ row: 2, demand: 300 }, { row: 5, demand: 450 }, { row: 8, demand: 400 }],
    communities: (() => {
      const c = [];
      const town = (r0, c0) => { for (let r = r0; r < r0 + 2; r++) for (let cc = c0; cc < c0 + 2; cc++) c.push({ row: r, col: cc }); };
      town(4, 9); town(1, 16); town(7, 20); town(4, 25);
      return c;
    })(),
    blocked: (() => {
      const b = [];
      const rect = (r0, r1, c0, c1) => { for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) b.push({ row: r, col: c }); };
      // Ås 1 – inledande bergrygg, lämnar botten öppen (rad 7–10)
      rect(0, 6, 6, 6); rect(0, 4, 7, 7);
      // Ås 2 – flankerar samhälle A; vägg vid kol 12–13 med pass rad 3–6
      rect(0, 2, 12, 13); rect(7, 10, 12, 13);
      // Pelarvägg vid kol 15 – enda passet ligger uppe vid samhälle B (rad 0–3)
      rect(4, 10, 15, 15);
      // Ås 3 – kläm mellan samhälle C och D
      rect(0, 2, 23, 23); rect(5, 7, 23, 24); rect(9, 10, 18, 19);
      return b;
    })(),
    target: 820,
  },
];
