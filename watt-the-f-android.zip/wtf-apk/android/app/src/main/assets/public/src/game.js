/* =========================================================================
   WATT THE F*  — spelmotor (Canvas, top-down pixelstil)
   Intermittens, batterier, förluster, inkomst, förgrenad forskning,
   startskärm och sparfunktion.
   ========================================================================= */

const CELL = 44;
const BIG = 1e9;                 // ersätter Infinity (JSON-säkert)
const REFUND = 0.8;              // återbetalning vid rivning (80%)
const SAVE_KEY = 'wattthef_save_v1';
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
ctx.imageSmoothingEnabled = false;
const dayCanvas = document.getElementById('dayCanvas');
const dctx = dayCanvas ? dayCanvas.getContext('2d') : null;

let state = null;
let nodeSeq = 0, edgeSeq = 0;
let lastTime = performance.now();
let gameStarted = false, paused = true, techBuilt = false;

/* ---------- Global forskning (persisterar mellan banor + sparas) ---------- */
const tech = { science: 0, researched: new Set(['start']), unlocked: null };
const completed = new Set();   // klarade scenarioindex

function deriveUnlocks() {
  tech.unlocked = {
    plant:   new Set(STARTING_UNLOCKS.plant),
    tower:   new Set(STARTING_UNLOCKS.tower),
    line:    new Set(STARTING_UNLOCKS.line),
    battery: new Set(STARTING_UNLOCKS.battery),
    lab:     new Set(STARTING_UNLOCKS.lab),
    bundle:  new Set(STARTING_UNLOCKS.bundle),
  };
  TECH_TREE.forEach(n => { if (tech.researched.has(n.id)) n.unlocks.forEach(u => tech.unlocked[u.type].add(u.key)); });
}
deriveUnlocks();

const isUnlocked = (t, k) => tech.unlocked[t].has(k);
const techById = id => TECH_TREE.find(n => n.id === id);
const techFor = (type, key) => TECH_TREE.find(n => n.unlocks.some(u => u.type === type && u.key === key));
const nodeDone = id => tech.researched.has(id);
const canResearch = n => !nodeDone(n.id) && n.prereqs.every(p => nodeDone(p));

function techMsg(msg, ok) {
  const el = document.getElementById('techMsg');
  if (el) { el.textContent = msg; el.style.color = ok ? '#7dffb0' : '#ff9a9a'; }
}
function research(n) {
  if (nodeDone(n.id) || n.id === 'start') return;
  if (!canResearch(n)) { Sound.sfx.error(); return techMsg('Kräver först: ' + n.prereqs.filter(p => !nodeDone(p)).map(p => techById(p).name).join(', '), false); }
  if (tech.science < n.cost) { Sound.sfx.error(); return techMsg('För lite FP — behöver ' + n.cost + ' (har ' + Math.floor(tech.science) + ').', false); }
  tech.science -= n.cost;
  tech.researched.add(n.id);
  deriveUnlocks();
  buildPalette();
  renderTechTree();
  saveState();
  techMsg('Upplåst: ' + n.name + '!', true);
  flash('Upplåst: ' + n.name + '!');
  Sound.sfx.research();
}

/* ---------- Uppstart av scenario ---------- */
function startScenario(index) {
  const sc = SCENARIOS[index];
  const blocked = new Set(sc.blocked.map(b => `${b.row},${b.col}`));
  const communities = new Set((sc.communities || []).map(c => `${c.row},${c.col}`));
  const nearComm = new Set();                       // celler intill ett samhälle (buffertzon)
  (sc.communities || []).forEach(({ row, col }) => {
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
      const r = row + dr, c = col + dc;
      if (r < 0 || c < 0 || r >= sc.rows || c >= sc.cols) continue;
      const key = `${r},${c}`;
      if (!communities.has(key)) nearComm.add(key);
    }
  });
  const nodes = [];
  sc.stations.forEach(st => nodes.push({
    id: ++nodeSeq, kind: 'station', key: 'station',
    row: st.row, col: sc.cols - 1, demand: st.demand, cap: BIG, span: BIG, cost: 0,
  }));
  const viewCols = sc.scroll ? Math.min(sc.cols, sc.viewCols || 14) : sc.cols;
  const stars = [];
  if ((BIOMES[sc.biome] || {}).stars) {
    let s = 987654321;
    const rnd = () => (s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
    const n = Math.floor(sc.cols * sc.rows * 0.13);
    for (let i = 0; i < n; i++) stars.push({ x: rnd() * sc.cols * CELL, y: rnd() * sc.rows * CELL, r: rnd() < 0.85 ? 1 : 2 });
  }
  const decor = [];
  {
    let s = 1234567;
    const rnd = () => (s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
    const density = sc.biome === 'rymd' ? 0.04 : 0.2;     // gles i rymden (planeter), tätare annars
    for (let r = 0; r < sc.rows; r++) for (let c = sc.buildCols; c < sc.cols - 1; c++) {
      if (blocked.has(`${r},${c}`) || communities.has(`${r},${c}`)) continue;
      if (rnd() < density) decor.push({ r, c, t: Math.floor(rnd() * 3) });
    }
  }
  state = {
    index, sc, blocked, communities, nearComm, nodes, edges: [], stars, decor,
    money: sc.startMoney, incomeNow: 0, lost: 0, researchPower: 0,
    tool: { category: 'plant', key: 'sol' }, bundle: 'simplex',
    pending: null, hover: null, produced: 0, transferred: 0,
    simTime: 0, sustainTimer: 0, won: false,
    cam: { x: 0, max: Math.max(0, (sc.cols - viewCols) * CELL), viewCols },
  };
  canvas.height = sc.rows * CELL;
  fitViewport();
  buildResearchPanel();
  buildPalette();
  updateHUD();
  const bi = BIOMES[sc.biome];
  document.getElementById('scenarioName').textContent = `${sc.id}. ${sc.name}` + (bi ? ` ${bi.emoji}` : '');
  document.getElementById('brief').textContent = (bi ? `${bi.emoji} ${bi.name} — ` : '') + sc.brief;
}

/* ---------- Hjälp ---------- */
const cellCenter = (r, c) => ({ x: c * CELL + CELL / 2, y: r * CELL + CELL / 2 });
const isBlocked = (r, c) => state.blocked.has(`${r},${c}`);
const isCommunity = (r, c) => state.communities.has(`${r},${c}`);
const isObstacle = (r, c) => isBlocked(r, c) || isCommunity(r, c);
const nearCommunityCell = (r, c) => state.nearComm.has(`${r},${c}`);
const inBuildZone = (c) => c < state.sc.buildCols;
const nodeAt = (r, c) => state.nodes.find(n => n.row === r && n.col === c);
const nodeById = (id) => state.nodes.find(n => n.id === id);
const cellDistance = (a, b) => Math.hypot(a.row - b.row, a.col - b.col);
const LOW_TOWERS = ['tra', 'betong'];
const LOW_LINES = ['jarn', 'koppar'];
function segmentCells(a, b) {
  const cells = [], steps = Math.ceil(cellDistance(a, b) * 3);
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    cells.push([Math.round(a.row + (b.row - a.row) * t), Math.round(a.col + (b.col - a.col) * t)]);
  }
  return cells;
}
function segmentCrossesObstacle(a, b) { return segmentCells(a, b).some(([r, c]) => isObstacle(r, c)); }
function segmentNearCommunity(a, b) { return segmentCells(a, b).some(([r, c]) => nearCommunityCell(r, c)); }

/* ---------- Tidssimulering ---------- */
function tick(dt) {
  const connected = new Set();
  state.edges.forEach(e => { connected.add(e.a); connected.add(e.b); });
  let producedConnected = 0;
  state.nodes.forEach(n => {
    if (n.kind === 'plant') {
      n.currentOutput = plantInstantOutput(n.key, state.simTime, n.id, state.sc.biome);
      if (connected.has(n.id)) producedConnected += n.currentOutput;
    }
  });
  const r = simulateTick(state.nodes, state.edges, dt, (BIOMES[state.sc.biome] || {}).lossMult);
  state.produced = producedConnected;
  state.transferred = r.delivered;
  state.lost = r.lost;
  state.researchPower = r.researchPower;
  state.edges.forEach(e => { e.flow = r.edgeFlow.get(e.id) || 0; });

  tech.science += r.researchPower * RESEARCH_RATE * dt;

  state.incomeNow = r.delivered * state.sc.incomeRate;
  state.money += state.incomeNow * dt;

  if (r.delivered >= state.sc.target - 0.5) state.sustainTimer += dt;
  else state.sustainTimer = Math.max(0, state.sustainTimer - dt * 0.7);
  if (state.sustainTimer >= state.sc.requiredSustain && !state.won) {
    state.won = true; completed.add(state.index); updateTabs(); Sound.sfx.win(); saveState();
  }

  state.simTime += dt;
  Sound.setFlow(Math.min(1, state.transferred / Math.max(1, state.sc.target)));
  updateHUD();
  updateResearchPanel();
}

/* ---------- Bygg / riv ---------- */
function recomputeEdgeCaps(nodeId) {
  state.edges.forEach(e => {
    if (e.a === nodeId || e.b === nodeId) {
      const a = nodeById(e.a), b = nodeById(e.b);
      e.cap = segmentCapacity(e.line, a.cap, b.cap, e.bundle || 1);
    }
  });
}
// Max bunt en nod tillåter: torn enligt klass, övriga noder begränsar inte (triplex)
function nodeBundleLimit(n) { return n.kind === 'tower' ? (TOWERS[n.key].bundle || 1) : 3; }

function tryPlace(row, col) {
  const t = state.tool;
  if (t.category === 'plant') {
    if (!inBuildZone(col)) return flash('Kraftverk byggs bara i produktionszonen (grön).');
    if (isObstacle(row, col) || nodeAt(row, col)) return;
    const p = PLANTS[t.key];
    if (state.money < p.cost) return flash('Inte råd.');
    state.money -= p.cost;
    state.nodes.push({ id: ++nodeSeq, kind: 'plant', key: t.key, row, col,
      output: p.output, currentOutput: 0, cap: BIG, span: BIG, cost: p.cost });
    Sound.sfx.place();
    return;
  }
  if (isObstacle(row, col)) return;
  if (col === state.sc.cols - 1) return flash('Högerkanten är reserverad för stationer.');
  const existing = nodeAt(row, col);

  if (t.category === 'tower') {
    const tw = TOWERS[t.key];
    if (nearCommunityCell(row, col) && !LOW_TOWERS.includes(t.key))
      return flash('Nära samhälle: bara trä-/betongtorn (annars en rutas mellanrum).');
    if (existing) {
      if (existing.kind !== 'tower' || existing.key === t.key) return;   // ersätt bara torn av annan typ
      const net = tw.cost - REFUND * existing.cost;                       // betala mellanskillnaden
      if (state.money < net) return flash('Inte råd.');
      state.money -= net;
      existing.key = t.key; existing.cap = tw.capacity; existing.span = tw.span; existing.cost = tw.cost;
      recomputeEdgeCaps(existing.id);
      Sound.sfx.place();
      return;
    }
    if (state.money < tw.cost) return flash('Inte råd.');
    state.money -= tw.cost;
    state.nodes.push({ id: ++nodeSeq, kind: 'tower', key: t.key, row, col, cap: tw.capacity, span: tw.span, cost: tw.cost });
    Sound.sfx.place();
  } else if (t.category === 'battery') {
    if (existing) return;
    const bt = BATTERIES[t.key]; if (state.money < bt.cost) return flash('Inte råd.');
    state.money -= bt.cost;
    state.nodes.push({ id: ++nodeSeq, kind: 'battery', key: t.key, row, col, capacity: bt.capacity, soc: 0,
      chargeRate: bt.chargeRate, dischargeRate: bt.dischargeRate, cap: bt.cap, span: bt.span, cost: bt.cost });
    Sound.sfx.place();
  } else if (t.category === 'lab') {
    if (existing) return;
    const lb = LABS[t.key]; if (state.money < lb.cost) return flash('Inte råd.');
    state.money -= lb.cost;
    state.nodes.push({ id: ++nodeSeq, kind: 'research', key: t.key, row, col, demand: lb.demand, cap: lb.cap, span: lb.span, cost: lb.cost });
    Sound.sfx.place();
  }
}
function firstUnlockedLine() { return Object.keys(LINES).find(k => isUnlocked('line', k)) || 'jarn'; }

function tryConnect(target) {
  if (!state.pending) { state.pending = target.id; return; }
  if (state.pending === target.id) { state.pending = null; return; }
  const a = nodeById(state.pending), b = target; state.pending = null;
  if (!a || !b) return;
  const lineKey = state.tool.category === 'line' ? state.tool.key : firstUnlockedLine();
  const line = LINES[lineKey];
  const existing = state.edges.find(e => (e.a === a.id && e.b === b.id) || (e.a === b.id && e.b === a.id));
  const dist = existing ? existing.len : cellDistance(a, b);
  const maxAllowed = Math.min(line.maxLen, a.span, b.span);
  if (dist > maxAllowed) return flash(`För långt: ${dist.toFixed(1)} > max ${maxAllowed} för ${line.name} + tornen.`);

  // bunt: vald nivå klampad mot tornens klass
  const selKey = isUnlocked('bundle', state.bundle) ? state.bundle : 'simplex';
  const wanted = bundleMultByKey(selKey);
  const bundle = Math.min(wanted, nodeBundleLimit(a), nodeBundleLimit(b));
  if (bundle < wanted) flash(`Tornen klarar bara ${['', 'simplex', 'duplex', 'triplex'][bundle]}.`);

  // samhälls-buffert: intill ett samhälle bara järn/koppar, annars en rutas mellanrum
  if (segmentNearCommunity(a, b) && !LOW_LINES.includes(lineKey))
    return flash('Nära samhälle: bara järn-/kopparlinor (annars en rutas mellanrum).');

  if (existing) {
    if (existing.line === lineKey && (existing.bundle || 1) === bundle) return;   // identiskt – ingen åtgärd
    const newCost = Math.ceil(dist) * line.cost * bundle;
    const net = newCost - REFUND * existing.cost;
    if (state.money < net) return flash('Inte råd.');
    state.money -= net;
    existing.line = lineKey; existing.bundle = bundle; existing.cost = newCost;
    existing.cap = segmentCapacity(lineKey, a.cap, b.cap, bundle);
    Sound.sfx.line();
    return;
  }

  if (segmentCrossesObstacle(a, b)) return flash('Linan korsar berg eller samhälle.');
  const cost = Math.ceil(dist) * line.cost * bundle;
  if (state.money < cost) return flash(`Inte råd (${cost} kr).`);
  state.money -= cost;
  state.edges.push({ id: ++edgeSeq, a: a.id, b: b.id, line: lineKey, bundle, len: dist,
    cap: segmentCapacity(lineKey, a.cap, b.cap, bundle), cost, flow: 0 });
  Sound.sfx.line();
}

function eraseAt(row, col, mx, my) {
  const n = nodeAt(row, col);
  if (n) {
    if (n.kind === 'station') return flash('Stationer kan inte tas bort.');
    state.money += n.cost * REFUND;
    state.edges = state.edges.filter(e => { if (e.a === n.id || e.b === n.id) { state.money += e.cost * REFUND; return false; } return true; });
    state.nodes = state.nodes.filter(x => x.id !== n.id);
    if (state.pending === n.id) state.pending = null;
    Sound.sfx.erase();
    return;
  }
  let best = null, bestD = 12;
  state.edges.forEach(e => {
    const pa = cellCenter(nodeById(e.a).row, nodeById(e.a).col), pb = cellCenter(nodeById(e.b).row, nodeById(e.b).col);
    const d = distToSegment(mx, my, pa, pb); if (d < bestD) { bestD = d; best = e; }
  });
  if (best) { state.money += best.cost * REFUND; state.edges = state.edges.filter(e => e.id !== best.id); Sound.sfx.erase(); }
}
function distToSegment(px, py, a, b) {
  const dx = b.x - a.x, dy = b.y - a.y, len2 = dx * dx + dy * dy || 1;
  let t = Math.max(0, Math.min(1, ((px - a.x) * dx + (py - a.y) * dy) / len2));
  return Math.hypot(px - (a.x + t * dx), py - (a.y + t * dy));
}

/* ---------- Inmatning ---------- */
// Anpassa synfältets bredd till spelplanens proportioner så kartan fyller ytan.
function fitViewport() {
  if (!state) return;
  const sc = state.sc;
  if (!sc.scroll) { canvas.width = sc.cols * CELL; canvas.height = sc.rows * CELL; return; }
  const stage = document.getElementById('stage');
  const sw = stage.clientWidth || 1, sh = stage.clientHeight || 1;
  let vc = Math.round(sc.rows * (sw / sh));          // kolumner som fyller bredden vid höjdanpassning
  vc = Math.max(8, Math.min(sc.cols, vc));
  state.cam.viewCols = vc;
  state.cam.max = Math.max(0, (sc.cols - vc) * CELL);
  state.cam.x = Math.max(0, Math.min(state.cam.max, state.cam.x));
  canvas.width = vc * CELL;
  canvas.height = sc.rows * CELL;
}
window.addEventListener('resize', fitViewport);

function eventCell(e) {
  const rect = canvas.getBoundingClientRect();
  const camX = state && state.cam ? state.cam.x : 0;
  const mx = (e.clientX - rect.left) * (canvas.width / rect.width) + camX;
  const my = (e.clientY - rect.top) * (canvas.height / rect.height);
  return { mx, my, col: Math.floor(mx / CELL), row: Math.floor(my / CELL) };
}
canvas.addEventListener('mousemove', e => {
  if (!state) return;
  const { row, col } = eventCell(e);
  state.hover = (row >= 0 && row < state.sc.rows && col >= 0 && col < state.sc.cols) ? { row, col } : null;
});
canvas.addEventListener('contextmenu', e => { e.preventDefault(); if (!state || paused) return; const { row, col, mx, my } = eventCell(e); eraseAt(row, col, mx, my); });
let panDown = false, panStartX = 0, panStartCam = 0, panMoved = false;
canvas.addEventListener('pointerdown', e => {
  if (!state || paused) return;
  panDown = true; panMoved = false; panStartX = e.clientX; panStartCam = state.cam.x;
  try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
});
canvas.addEventListener('pointermove', e => {
  if (!state || paused || !panDown || state.cam.max <= 0) return;
  const rect = canvas.getBoundingClientRect();
  const dx = (e.clientX - panStartX) * (canvas.width / rect.width);
  if (Math.abs(dx) > 6) panMoved = true;
  if (panMoved) state.cam.x = Math.max(0, Math.min(state.cam.max, panStartCam - dx));
});
window.addEventListener('pointerup', e => { panDown = false; try { canvas.releasePointerCapture(e.pointerId); } catch (_) {} });
canvas.addEventListener('pointercancel', () => { panDown = false; panMoved = false; });
canvas.addEventListener('wheel', e => {
  if (!state || paused || state.cam.max <= 0) return;
  e.preventDefault();
  state.cam.x = Math.max(0, Math.min(state.cam.max, state.cam.x + (e.deltaX || e.deltaY)));
}, { passive: false });
canvas.addEventListener('click', e => {
  if (!state || paused) return;
  if (panMoved) { panMoved = false; return; }   // panorering, inte ett klick
  const { row, col, mx, my } = eventCell(e);
  if (row < 0 || row >= state.sc.rows || col < 0 || col >= state.sc.cols) return;
  if (state.tool.category === 'line') { const n = nodeAt(row, col); if (n) tryConnect(n); else flash('Klicka på en nod för att dra lina.'); }
  else if (state.tool.category === 'erase') eraseAt(row, col, mx, my);
  else tryPlace(row, col);
});
window.addEventListener('keydown', e => {
  if (!gameStarted) return;
  if (e.key === 'Escape') {
    if (document.getElementById('techTree').style.display === 'flex') return closeTechTree();
    if (state) state.pending = null;
  }
  if ((e.key === 'r' || e.key === 'R') && state && !paused) startScenario(state.index);
});

/* ---------- HUD ---------- */
let flashTimer = 0, flashMsg = '';
function flash(msg) { flashMsg = msg; flashTimer = performance.now() + 2400; }
function updateHUD() {
  document.getElementById('money').textContent = Math.floor(state.money);
  document.getElementById('income').textContent = '+' + state.incomeNow.toFixed(1);
  document.getElementById('produced').textContent = Math.round(state.produced);
  document.getElementById('transferred').textContent = Math.round(state.transferred);
  document.getElementById('target').textContent = state.sc.target;
  document.getElementById('lost').textContent = Math.round(state.lost);
  document.getElementById('progressFill').style.width = Math.min(100, (state.transferred / state.sc.target) * 100) + '%';
  document.getElementById('stabilityFill').style.width = Math.min(100, (state.sustainTimer / state.sc.requiredSustain) * 100) + '%';
  document.getElementById('winBanner').style.display = state.won ? 'flex' : 'none';
}

/* ---------- Forskningspanel (sidofält) ---------- */
function buildResearchPanel() {
  const el = document.getElementById('research');
  el.innerHTML = `<div class="pal-group-title">Forskning</div>
    <div class="res-row">FP: <b id="sciVal">0</b></div>
    <button class="res-btn" id="openTech">⚛ Forskningsträd</button>`;
  document.getElementById('openTech').onclick = openTechTree;
}
function updateResearchPanel() { const s = document.getElementById('sciVal'); if (s) s.textContent = Math.floor(tech.science); }

/* ---------- Palett ---------- */
function buildPalette() {
  const pal = document.getElementById('palette'); pal.innerHTML = '';
  const group = (title, items, type, stats) => {
    const entries = Object.entries(items).filter(([key]) => isUnlocked(type, key));
    if (entries.length === 0) return;          // dölj hela gruppen om inget är upplåst än
    const h = document.createElement('div'); h.className = 'pal-group-title'; h.textContent = title; pal.appendChild(h);
    entries.forEach(([key, v]) => {
      const btn = document.createElement('button');
      btn.className = 'pal-btn'; btn.dataset.cat = type; btn.dataset.key = key;
      btn.innerHTML = `<span class="sw" style="background:${v.color}"></span><span class="pal-name">${v.name}</span><span class="pal-stats">${stats(v)}</span>`;
      btn.onclick = () => { Sound.sfx.click(); state.tool = { category: type, key }; state.pending = null; highlight(); };
      pal.appendChild(btn);
    });
  };
  group('Kraftverk', PLANTS, 'plant', v => `${v.output}W${v.variable ? '*' : ''} · ${v.cost}kr`);
  group('Torn', TOWERS, 'tower', v => `${v.capacity}W · ${v.span}c · ${v.cost}kr`);
  group('Linor', LINES, 'line', v => `${v.capacity}W · ${v.maxLen}c · ${Math.round(v.loss*100)}%/c`);
  // Bunt-väljare (visas först när duplex/triplex forskats fram)
  const bundleKeys = Object.keys(BUNDLES).filter(k => isUnlocked('bundle', k));
  if (bundleKeys.length > 1) {
    const bh = document.createElement('div'); bh.className = 'pal-group-title'; bh.textContent = 'Bunt'; pal.appendChild(bh);
    bundleKeys.forEach(k => {
      const v = BUNDLES[k];
      const btn = document.createElement('button');
      btn.className = 'pal-btn'; btn.dataset.bundle = k;
      btn.innerHTML = `<span class="sw" style="background:#3a5a8a"></span><span class="pal-name">${v.name}</span><span class="pal-stats">×${v.mult} kap · /${v.mult} förlust</span>`;
      btn.onclick = () => { Sound.sfx.click(); state.bundle = k; highlight(); };
      pal.appendChild(btn);
    });
  }
  group('Lager', BATTERIES, 'battery', v => `${(v.capacity/1000).toFixed(1)}kWs · ${v.cost}kr`);
  group('Forskning', LABS, 'lab', v => `−${v.demand}W · ${v.cost}kr`);
  const h = document.createElement('div'); h.className = 'pal-group-title'; h.textContent = 'Verktyg'; pal.appendChild(h);
  const erase = document.createElement('button');
  erase.className = 'pal-btn'; erase.dataset.cat = 'erase'; erase.dataset.key = 'erase';
  erase.innerHTML = `<span class="sw" style="background:#a33"></span><span class="pal-name">Riv</span><span class="pal-stats">återbetalar</span>`;
  erase.onclick = () => { state.tool = { category: 'erase', key: 'erase' }; state.pending = null; highlight(); };
  pal.appendChild(erase);
  highlight();
}
function highlight() {
  document.querySelectorAll('.pal-btn').forEach(b => {
    if (b.dataset.bundle) b.classList.toggle('active', b.dataset.bundle === state.bundle);
    else b.classList.toggle('active', b.dataset.cat === state.tool.category && b.dataset.key === state.tool.key);
  });
}

/* ---------- Forskningsträd-overlay ---------- */
const T_SPX = 160, T_SPY = 84, T_PAD = 20, T_W = 132, T_H = 64;
function tpos(n) { return { x: T_PAD + n.tier * T_SPX, y: T_PAD + n.row * T_SPY }; }
// Synlig (utforskad) = forskad ELLER har minst en forskad förkunskap (frontlinjen)
function techVisible(n) { return nodeDone(n.id) || n.prereqs.some(p => nodeDone(p)); }

function renderTechTree() {
  const nodesEl = document.getElementById('techNodes');
  const svg = document.getElementById('techEdges');
  nodesEl.innerHTML = ''; svg.innerHTML = '';
  let maxTier = 0, maxRow = 0;
  TECH_TREE.forEach(n => { maxTier = Math.max(maxTier, n.tier); maxRow = Math.max(maxRow, n.row); });
  const W = T_PAD * 2 + maxTier * T_SPX + T_W, H = T_PAD * 2 + maxRow * T_SPY + T_H;
  document.getElementById('techCanvasWrap').style.width = W + 'px';
  document.getElementById('techCanvasWrap').style.height = H + 'px';
  svg.setAttribute('width', W); svg.setAttribute('height', H);
  // kanter (dämpade in i dimman)
  TECH_TREE.forEach(n => {
    const p = tpos(n);
    n.prereqs.forEach(pr => {
      const q = tpos(techById(pr));
      const x1 = q.x + T_W, y1 = q.y + T_H / 2, x2 = p.x, y2 = p.y + T_H / 2, mx = (x1 + x2) / 2;
      const line = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      line.setAttribute('d', `M ${x1} ${y1} C ${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2}`);
      const dim = !techVisible(n);
      line.setAttribute('stroke', dim ? '#19202f' : '#2a3a5a');
      line.setAttribute('stroke-width', dim ? '1.5' : '2');
      if (dim) line.setAttribute('stroke-dasharray', '3 5');
      line.setAttribute('fill', 'none');
      svg.appendChild(line);
    });
  });
  // noder
  TECH_TREE.forEach(n => {
    const p = tpos(n);
    const div = document.createElement('div');
    div.id = 'tn_' + n.id; div.style.left = p.x + 'px'; div.style.top = p.y + 'px';
    if (!techVisible(n)) {
      div.className = 'tnode fog';
      div.innerHTML = `<div class="tn-fog">?</div>`;
    } else {
      let cls = 'tnode';
      if (n.id === 'start' || nodeDone(n.id)) cls += ' done';
      else if (canResearch(n)) cls += tech.science >= n.cost ? ' available' : ' poor';
      else cls += ' locked';
      if (n.id === 'start') cls += ' root';
      div.className = cls;
      const unlockTxt = n.unlocks.map(u => recipeName(u)).join(', ') || 'bas';
      div.innerHTML = `<div class="tn-name">${n.name}</div><div class="tn-unlock">${unlockTxt}</div><div class="tn-cost">${n.id==='start'?'start':n.cost+' FP'}</div>`;
      if (n.id !== 'start' && !nodeDone(n.id)) div.onclick = () => research(n);
    }
    nodesEl.appendChild(div);
  });
  const fp = document.getElementById('techFP'); if (fp) fp.textContent = Math.floor(tech.science);
}
function recipeName(u) {
  const map = { plant: PLANTS, tower: TOWERS, line: LINES, battery: BATTERIES, lab: LABS, bundle: BUNDLES };
  return (map[u.type] || {})[u.key]?.name || u.key;
}
function openTechTree() {
  techMsg('', true);
  renderTechTree();
  document.getElementById('techTree').style.display = 'flex';
  paused = true;
}
function closeTechTree() { document.getElementById('techTree').style.display = 'none'; if (gameStarted) paused = false; }

/* ---------- Spara / ladda ---------- */
function serialize() {
  return { v: 1, science: tech.science, researched: [...tech.researched], completed: [...completed],
    scenarioIndex: state.index, money: state.money, simTime: state.simTime,
    sustainTimer: state.sustainTimer, won: state.won,
    nodes: state.nodes, edges: state.edges, nodeSeq, edgeSeq };
}
function saveState() { try { if (state) localStorage.setItem(SAVE_KEY, JSON.stringify(serialize())); } catch (e) {} }
function hasSave() { try { return !!localStorage.getItem(SAVE_KEY); } catch (e) { return false; } }
function applySave(s) {
  tech.science = s.science || 0;
  tech.researched = new Set(s.researched && s.researched.length ? s.researched : ['start']);
  completed.clear(); (s.completed || []).forEach(i => completed.add(i));
  deriveUnlocks();
  startScenario(s.scenarioIndex || 0);
  state.money = s.money; state.simTime = s.simTime || 0; state.sustainTimer = s.sustainTimer || 0; state.won = !!s.won;
  state.nodes = s.nodes; state.edges = s.edges; nodeSeq = s.nodeSeq || nodeSeq; edgeSeq = s.edgeSeq || edgeSeq;
  buildPalette(); updateHUD(); updateResearchPanel(); techBuilt = false;
  updateTabs(s.scenarioIndex || 0);
}
function loadState() {
  try { const raw = localStorage.getItem(SAVE_KEY); if (!raw) return false; applySave(JSON.parse(raw)); return true; }
  catch (e) { return false; }
}
function exportSave() {
  if (!state) return;
  const blob = new Blob([JSON.stringify(serialize(), null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = 'wattthef-save.json'; a.click();
  URL.revokeObjectURL(a.href);
}
function importSave(file) {
  const reader = new FileReader();
  reader.onload = () => { try { applySave(JSON.parse(reader.result)); enterGame(); flash('Sparfil laddad.'); } catch (e) { flash('Ogiltig sparfil.'); } };
  reader.readAsText(file);
}

/* ---------- Start / meny ---------- */
function newGame() {
  tech.science = 0; tech.researched = new Set(['start']); completed.clear(); deriveUnlocks(); techBuilt = false;
  startScenario(0);
  updateTabs(0);
  enterGame(); saveState();
}
function enterGame() {
  gameStarted = true; paused = false;
  document.getElementById('startScreen').style.display = 'none';
  document.getElementById('techTree').style.display = 'none';
  fitViewport();
  Sound.stopMusic();
}
function openMenu() { saveState(); paused = true; Sound.setFlow(0); Sound.startMusic(); document.getElementById('startScreen').style.display = 'flex'; refreshContinue(); }
function refreshContinue() { document.getElementById('btnContinue').disabled = !hasSave(); }

/* En bana är upplåst om den är den första eller om föregående är klarad */
function scenarioUnlocked(i) { return i === 0 || completed.has(i - 1); }

/* Uppdatera scenarioflikar: aktiv + klarat-bock + lås */
function updateTabs(activeIndex) {
  const tabs = document.querySelectorAll('.tab');
  tabs.forEach((tab, i) => {
    const done = completed.has(i);
    const locked = !scenarioUnlocked(i);
    tab.classList.toggle('done', done);
    tab.classList.toggle('locked', locked);
    tab.classList.toggle('active', activeIndex !== undefined ? i === activeIndex : tab.classList.contains('active'));
    tab.textContent = locked ? '🔒' : SCENARIOS[i].id + (done ? '✓' : '');
  });
}

/* ---------- Rendering ---------- */
function draw(time) {
  const dt = Math.min(0.05, (time - lastTime) / 1000); lastTime = time;
  requestAnimationFrame(draw);
  if (!state || paused) { Sound.setFlow(0); return; }
  tick(dt);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.save(); ctx.translate(-Math.round(state.cam.x), 0);
  drawTerrain(); drawEdges(time); drawPendingPreview(); drawNodes(); drawHover();
  ctx.restore();
  drawDayNight(); drawFlash(); drawScrollBar();
  drawDayWidget();
}
function drawScrollBar() {
  if (!state.cam || state.cam.max <= 0) return;
  const trackW = canvas.width, y = canvas.height - 5;
  const frac = state.cam.viewCols / state.sc.cols;
  const thumbW = Math.max(34, trackW * frac);
  const thumbX = (state.cam.x / state.cam.max) * (trackW - thumbW);
  ctx.fillStyle = 'rgba(255,255,255,0.08)'; ctx.fillRect(0, y, trackW, 4);
  ctx.fillStyle = 'rgba(120,180,255,0.55)'; ctx.fillRect(thumbX, y, thumbW, 4);
}
function biomePal() { return BIOMES[state.sc.biome] || BIOMES.lovskog; }
function shade(hex, amt) {
  let r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
  if (amt >= 0) { r += (255 - r) * amt; g += (255 - g) * amt; b += (255 - b) * amt; }
  else { const k = 1 + amt; r *= k; g *= k; b *= k; }
  return `rgb(${r | 0},${g | 0},${b | 0})`;
}
function softBlob(x, y, r, rgb, a) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, `rgba(${rgb},${a})`); g.addColorStop(1, `rgba(${rgb},0)`);
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
}
function vWash(W, H, top, bot) {
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, top); g.addColorStop(1, bot);
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
}
function blobRow(W, y, r, rgb, a, n) {
  for (let i = 0; i < n; i++) softBlob(W * (i + 0.5) / n, y + (i % 2 ? r * 0.18 : -r * 0.18), r, rgb, a);
}
// Atmosfärisk bakgrund per biom – mjuk dimma ovanpå rutorna
function drawBiomeBackground(W, H) {
  switch (state.sc.biome) {
    case 'lovskog':
      vWash(W, H, 'rgba(80,160,90,0.06)', 'rgba(30,80,45,0.10)');
      softBlob(W * 0.25, H * 0.30, 150, '180,230,150', 0.06);
      softBlob(W * 0.70, H * 0.62, 180, '150,210,140', 0.06);
      break;
    case 'oken':
      vWash(W, H, 'rgba(245,215,140,0.08)', 'rgba(190,140,70,0.10)');
      blobRow(W, H * 0.60, 130, '240,205,120', 0.08, 4);
      blobRow(W, H * 0.84, 160, '220,175,95', 0.10, 3);
      softBlob(W * 0.86, H * 0.16, 130, '255,235,160', 0.12);
      break;
    case 'vinter':
      vWash(W, H, 'rgba(170,210,245,0.07)', 'rgba(90,130,190,0.10)');
      blobRow(W, H * 0.16, 120, '120,255,200', 0.07, 4);
      blobRow(W, H * 0.30, 130, '180,180,255', 0.06, 3);
      break;
    case 'trask':
      vWash(W, H, 'rgba(100,160,110,0.07)', 'rgba(30,70,45,0.11)');
      softBlob(W * 0.30, H * 0.40, 160, '190,225,180', 0.07);
      softBlob(W * 0.66, H * 0.52, 190, '160,210,170', 0.07);
      softBlob(W * 0.50, H * 0.78, 170, '180,215,180', 0.06);
      break;
    case 'rymd':
      softBlob(W * 0.20, H * 0.32, 210, '150,90,230', 0.18);
      softBlob(W * 0.56, H * 0.56, 250, '70,130,230', 0.15);
      softBlob(W * 0.82, H * 0.24, 180, '230,90,190', 0.12);
      break;
  }
}
function drawDecor(d) {
  const x = d.c * CELL, y = d.r * CELL, cx = x + CELL / 2, cy = y + CELL / 2;
  ctx.save();
  switch (state.sc.biome) {
    case 'lovskog':
      ctx.globalAlpha = 0.85;
      ctx.fillStyle = '#43301c'; ctx.fillRect(cx - 1.5, cy + 1, 3, 8);
      ctx.fillStyle = d.t === 0 ? '#1f6b32' : d.t === 1 ? '#1a7a3c' : '#2a8a44';
      if (d.t === 1) { ctx.beginPath(); ctx.moveTo(cx, cy - 11); ctx.lineTo(cx - 7, cy + 3); ctx.lineTo(cx + 7, cy + 3); ctx.closePath(); ctx.fill(); }
      else { ctx.beginPath(); ctx.arc(cx, cy - 2, d.t === 0 ? 7 : 5, 0, 7); ctx.fill(); }
      break;
    case 'oken':
      ctx.globalAlpha = 0.85;
      if (d.t === 0) {
        ctx.fillStyle = '#2f7d3a';
        ctx.fillRect(cx - 2, cy - 7, 4, 15); ctx.fillRect(cx - 7, cy - 1, 5, 3); ctx.fillRect(cx - 7, cy - 5, 3, 5);
        ctx.fillRect(cx + 2, cy + 1, 5, 3); ctx.fillRect(cx + 4, cy - 4, 3, 6);
      } else if (d.t === 1) {
        ctx.strokeStyle = '#9c6a2e'; ctx.lineWidth = 2; ctx.globalAlpha = 0.6;
        ctx.beginPath(); ctx.moveTo(x + 6, cy + 6); ctx.quadraticCurveTo(cx, cy - 3, x + CELL - 6, cy + 6); ctx.stroke();
      } else { ctx.fillStyle = '#7a5630'; ctx.beginPath(); ctx.ellipse(cx, cy + 4, 6, 4, 0, 0, 7); ctx.fill(); }
      break;
    case 'vinter':
      ctx.globalAlpha = 0.9;
      if (d.t === 0) { ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.ellipse(cx, cy + 6, 11, 4, 0, 0, 7); ctx.fill(); }
      else if (d.t === 1) {
        ctx.strokeStyle = '#4a3826'; ctx.lineWidth = 1.5; ctx.beginPath();
        ctx.moveTo(cx, cy + 8); ctx.lineTo(cx, cy - 8);
        ctx.moveTo(cx, cy - 3); ctx.lineTo(cx - 5, cy - 8); ctx.moveTo(cx, cy - 3); ctx.lineTo(cx + 5, cy - 8);
        ctx.moveTo(cx, cy + 1); ctx.lineTo(cx - 4, cy - 2); ctx.moveTo(cx, cy + 1); ctx.lineTo(cx + 4, cy - 2); ctx.stroke();
      } else {
        ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.2;
        for (let i = 0; i < 3; i++) { const a = i * Math.PI / 3; ctx.beginPath(); ctx.moveTo(cx - Math.cos(a) * 5, cy - Math.sin(a) * 5); ctx.lineTo(cx + Math.cos(a) * 5, cy + Math.sin(a) * 5); ctx.stroke(); }
      }
      break;
    case 'trask':
      ctx.globalAlpha = 0.8;
      if (d.t === 0) {
        ctx.fillStyle = 'rgba(20,75,75,0.7)'; ctx.beginPath(); ctx.ellipse(cx, cy + 3, 10, 6, 0, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(150,220,200,0.5)'; ctx.beginPath(); ctx.ellipse(cx - 2, cy + 1, 4, 1.5, 0, 0, 7); ctx.fill();
      } else if (d.t === 1) {
        ctx.strokeStyle = '#1f5f30'; ctx.lineWidth = 1.6;
        [-4, 0, 4].forEach(o => { ctx.beginPath(); ctx.moveTo(cx + o, cy + 8); ctx.lineTo(cx + o + o * 0.3, cy - 7); ctx.stroke(); });
      } else { ctx.fillStyle = '#1f6b30'; ctx.beginPath(); ctx.arc(cx, cy + 2, 6, 0.5, 6.8); ctx.fill(); }
      break;
    case 'rymd': {
      ctx.globalAlpha = 0.9;
      const cols = ['#8a6fd0', '#5aa0d8', '#d06fb0'];
      ctx.fillStyle = cols[d.t % 3]; ctx.beginPath(); ctx.arc(cx, cy, d.t === 0 ? 7 : 5, 0, 7); ctx.fill();
      if (d.t === 0) { ctx.strokeStyle = '#d8c8f0'; ctx.lineWidth = 1.5; ctx.globalAlpha = 0.7; ctx.beginPath(); ctx.ellipse(cx, cy, 11, 3.5, -0.4, 0, 7); ctx.stroke(); }
      break;
    }
  }
  ctx.restore();
}
function drawTerrain() {
  const { sc } = state; const P = biomePal();
  for (let r = 0; r < sc.rows; r++) for (let c = 0; c < sc.cols; c++) {
    const x = c * CELL, y = r * CELL;
    let fill = P.cell; if (inBuildZone(c)) fill = P.build; if (c === sc.cols - 1) fill = P.station;
    ctx.fillStyle = fill; ctx.fillRect(x, y, CELL, CELL);
    ctx.strokeStyle = 'rgba(0,0,0,0.16)'; ctx.strokeRect(x + 0.5, y + 0.5, CELL, CELL);
  }
  drawBiomeBackground(sc.cols * CELL, sc.rows * CELL);
  if (state.stars && state.stars.length) {
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    state.stars.forEach(s => ctx.fillRect(s.x, s.y, s.r, s.r));
  }
  if (state.decor) state.decor.forEach(d => drawDecor(d));
  ctx.fillStyle = P.label; ctx.font = 'bold 11px monospace';
  ctx.save(); ctx.translate(10, sc.rows * CELL / 2); ctx.rotate(-Math.PI / 2);
  ctx.textAlign = 'center'; ctx.fillText('PRODUKTIONSZON', 0, 0); ctx.restore();
  state.nearComm.forEach(k => { const [r, c] = k.split(',').map(Number); ctx.fillStyle = P.near; ctx.fillRect(c * CELL, r * CELL, CELL, CELL); });
  state.blocked.forEach(k => { const [r, c] = k.split(',').map(Number); drawMountain(c * CELL, r * CELL); });
  state.communities.forEach(k => { const [r, c] = k.split(',').map(Number); drawCommunity(c * CELL, r * CELL); });
}
function drawCommunity(x, y) {
  const P = biomePal();
  ctx.fillStyle = P.pad; ctx.fillRect(x + 2, y + 2, CELL - 4, CELL - 4);
  const house = (hx, hy, w, h, wall) => {
    ctx.fillStyle = '#b05a48'; ctx.beginPath();
    ctx.moveTo(hx - 2, hy); ctx.lineTo(hx + w / 2, hy - w * 0.55); ctx.lineTo(hx + w + 2, hy); ctx.closePath(); ctx.fill();
    ctx.fillStyle = wall; ctx.fillRect(hx, hy, w, h);
    ctx.fillStyle = 'rgba(255,210,120,0.95)'; ctx.fillRect(hx + w / 2 - 1.5, hy + 3, 3, 3);
  };
  house(x + 9, y + 19, 12, 12, '#cdd6e0');
  house(x + 25, y + 24, 9, 8, '#aeb8c4');
}
function drawMountain(x, y) {
  const P = biomePal();
  ctx.fillStyle = shade(P.mtnBase, -0.3); ctx.fillRect(x + 3, y + 3, CELL - 6, CELL - 6);
  ctx.fillStyle = P.mtnBase; ctx.beginPath();
  ctx.moveTo(x + 7, y + CELL - 8); ctx.lineTo(x + CELL / 2, y + 9); ctx.lineTo(x + CELL - 7, y + CELL - 8); ctx.closePath(); ctx.fill();
  ctx.fillStyle = P.mtnPeak; ctx.beginPath();
  ctx.moveTo(x + CELL / 2 - 5, y + 17); ctx.lineTo(x + CELL / 2, y + 9); ctx.lineTo(x + CELL / 2 + 5, y + 17); ctx.closePath(); ctx.fill();
}
function drawEdges(time) {
  state.edges.forEach(e => {
    const a = nodeById(e.a), b = nodeById(e.b);
    const pa = cellCenter(a.row, a.col), pb = cellCenter(b.row, b.col);
    const active = Math.abs(e.flow) > 0.001;
    const bundle = e.bundle || 1;
    const dx = pb.x - pa.x, dy = pb.y - pa.y, len = Math.hypot(dx, dy) || 1;
    const px = -dy / len, py = dx / len;
    ctx.lineWidth = 2.6; ctx.strokeStyle = active ? '#10314e' : LINES[e.line].color; ctx.globalAlpha = active ? 1 : 0.8;
    for (let i = 0; i < bundle; i++) {
      const off = (i - (bundle - 1) / 2) * 3.2;
      ctx.beginPath(); ctx.moveTo(pa.x + px*off, pa.y + py*off); ctx.lineTo(pb.x + px*off, pb.y + py*off); ctx.stroke();
    }
    ctx.globalAlpha = 1;
    if (active) drawFlow(pa, pb, e, time);
  });
}
function drawFlow(pa, pb, e, time) {
  const dir = e.flow >= 0 ? 1 : -1;
  const from = dir > 0 ? pa : pb, to = dir > 0 ? pb : pa;
  const dx = to.x - from.x, dy = to.y - from.y, len = Math.hypot(dx, dy) || 1;
  const px = -dy / len, py = dx / len, load = Math.min(1, Math.abs(e.flow) / e.cap);
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.strokeStyle = `rgba(40,120,255,${0.10 + load * 0.15})`; ctx.lineWidth = 8;
  ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.lineTo(pb.x, pb.y); ctx.stroke();
  const speed = 90, spacing = 26, phase = (time / 1000 * speed) % spacing;
  ctx.strokeStyle = `rgba(120,200,255,${0.5 + load * 0.4})`; ctx.lineWidth = 2.5;
  ctx.setLineDash([7, spacing - 7]); ctx.lineDashOffset = -phase;
  ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke(); ctx.setLineDash([]);
  const boltHead = (time / 1000 * speed * 1.4) % (len + 40) - 20, segs = 6, reach = 28;
  ctx.strokeStyle = 'rgba(180,230,255,0.7)'; ctx.lineWidth = 1.4; ctx.beginPath();
  for (let i = 0; i <= segs; i++) {
    const along = boltHead + (i / segs) * reach; if (along < 0 || along > len) continue;
    const t = along / len, jit = Math.sin(i * 12.9 + time / 60) * 4 * (1 - load * 0.3);
    const x = from.x + dx * t + px * jit, y = from.y + dy * t + py * jit;
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.stroke(); ctx.restore();
}
function drawPendingPreview() {
  if (!state.pending || !state.hover) return;
  const a = nodeById(state.pending); if (!a) return;
  const pa = cellCenter(a.row, a.col), pb = cellCenter(state.hover.row, state.hover.col);
  const lineKey = state.tool.category === 'line' ? state.tool.key : firstUnlockedLine();
  const line = LINES[lineKey], tgt = { row: state.hover.row, col: state.hover.col }, dist = cellDistance(a, tgt);
  const nearBad = segmentNearCommunity(a, tgt) && !LOW_LINES.includes(lineKey);
  const ok = dist <= Math.min(line.maxLen, a.span) && !segmentCrossesObstacle(a, tgt) && !nearBad;
  ctx.strokeStyle = ok ? 'rgba(120,200,255,0.8)' : 'rgba(255,90,90,0.8)';
  ctx.lineWidth = 2; ctx.setLineDash([5, 5]);
  ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.lineTo(pb.x, pb.y); ctx.stroke(); ctx.setLineDash([]);
}
function drawNodes() {
  state.nodes.forEach(n => {
    const { x, y } = cellCenter(n.row, n.col);
    if (n.kind === 'plant') drawPlant(x, y, n);
    else if (n.kind === 'tower') drawTower(x, y, n);
    else if (n.kind === 'battery') drawBattery(x, y, n);
    else if (n.kind === 'research') drawLab(x, y, n);
    else drawStation(x, y, n);
    if (n.id === state.pending) { ctx.strokeStyle = '#ffe14d'; ctx.lineWidth = 2; ctx.strokeRect(x - CELL/2 + 3, y - CELL/2 + 3, CELL - 6, CELL - 6); }
  });
}
function drawPlant(x, y, n) {
  const p = PLANTS[n.key], lit = (n.currentOutput || 0) > 1;
  ctx.fillStyle = '#0c0f16'; ctx.fillRect(x - 16, y - 16, 32, 32);
  ctx.fillStyle = lit ? p.color : '#3a3f48'; ctx.fillRect(x - 13, y - 13, 26, 26);
  ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(x - 13, y + 5, 26, 8);
  ctx.fillStyle = '#0c0f16'; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(n.key.slice(0, 3).toUpperCase(), x, y - 3); ctx.fillText(Math.round(n.currentOutput || 0) + 'W', x, y + 9);
}
function drawTower(x, y, n) {
  const t = TOWERS[n.key];
  ctx.strokeStyle = t.color; ctx.lineWidth = 2; ctx.beginPath();
  ctx.moveTo(x - 11, y + 12); ctx.lineTo(x, y - 13); ctx.lineTo(x + 11, y + 12);
  ctx.moveTo(x - 7, y + 1); ctx.lineTo(x + 7, y + 1); ctx.moveTo(x - 9, y + 7); ctx.lineTo(x + 9, y + 7);
  ctx.moveTo(x - 4, y - 6); ctx.lineTo(x + 4, y - 6); ctx.stroke();
  ctx.fillStyle = t.color; ctx.beginPath(); ctx.arc(x, y - 13, 2.2, 0, Math.PI * 2); ctx.fill();
}
function drawBattery(x, y, n) {
  const bt = BATTERIES[n.key];
  ctx.fillStyle = '#0c0f16'; ctx.fillRect(x - 14, y - 16, 28, 32);
  ctx.strokeStyle = bt.color; ctx.lineWidth = 2; ctx.strokeRect(x - 11, y - 13, 22, 26);
  ctx.fillStyle = '#2a3340'; ctx.fillRect(x - 9, y - 11, 18, 22);
  const soc = Math.max(0, Math.min(1, n.soc / n.capacity)), h = Math.round(22 * soc);
  ctx.fillStyle = bt.color; ctx.fillRect(x - 9, y + 11 - h, 18, h);
  ctx.fillStyle = bt.color; ctx.fillRect(x - 3, y - 16, 6, 3);
}
function drawLab(x, y, n) {
  const lb = LABS[n.key], active = (state.researchPower || 0) > 0;
  ctx.fillStyle = '#0c0f16'; ctx.fillRect(x - 15, y - 15, 30, 30);
  ctx.fillStyle = '#1c1430'; ctx.fillRect(x - 12, y - 12, 24, 24);
  ctx.strokeStyle = lb.color; ctx.lineWidth = 2; ctx.strokeRect(x - 12, y - 12, 24, 24);
  ctx.strokeStyle = active ? '#e6c2ff' : '#5a4a72'; ctx.lineWidth = 2; ctx.beginPath();
  ctx.moveTo(x - 4, y - 7); ctx.lineTo(x - 4, y - 1); ctx.lineTo(x - 8, y + 7); ctx.lineTo(x + 8, y + 7); ctx.lineTo(x + 4, y - 1); ctx.lineTo(x + 4, y - 7); ctx.stroke();
  if (active) { ctx.fillStyle = lb.color; ctx.beginPath(); ctx.arc(x, y + 3, 3, 0, Math.PI * 2); ctx.fill(); }
  ctx.fillStyle = '#b98cff'; ctx.font = 'bold 8px monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText('−' + lb.demand + 'W', x, y + 20);
}
function drawStation(x, y, n) {
  ctx.fillStyle = '#0c0f16'; ctx.fillRect(x - 16, y - 16, 32, 32);
  const met = state.transferred > 0;
  ctx.fillStyle = '#3a2a4a'; ctx.fillRect(x - 13, y - 13, 26, 26);
  ctx.fillStyle = met ? '#ffd24d' : '#5a4a2a';
  for (let i = 0; i < 3; i++) for (let j = 0; j < 2; j++) ctx.fillRect(x - 10 + i * 8, y - 9 + j * 9, 4, 5);
  ctx.fillStyle = '#c8d8f0'; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(n.demand + 'W', x, y + 21);
  ctx.fillStyle = '#7ec8ff'; ctx.beginPath();
  ctx.moveTo(x + 1, y - 8); ctx.lineTo(x - 4, y + 1); ctx.lineTo(x - 1, y + 1); ctx.lineTo(x - 3, y + 9); ctx.lineTo(x + 5, y - 2); ctx.lineTo(x + 1, y - 2); ctx.closePath(); ctx.fill();
}
function drawDayNight() {
  const daylight = Math.max(0, Math.sin((state.simTime / DAY_LENGTH) * 2 * Math.PI)), night = 1 - daylight;
  const [nr, ng, nb] = biomePal().night || [8, 12, 30];
  if (night > 0.01) { ctx.fillStyle = `rgba(${nr},${ng},${nb},${night * 0.28})`; ctx.fillRect(0, 0, canvas.width, canvas.height); }
}

// Liten dygnsindikator: sol/måne i en båge, höjden = solkraftens effekt just nu
function drawDayWidget() {
  if (!dctx || !state) return;
  const W = 132, H = 46, horizon = 33, peak = 22, lx = 14, rx = W - 14;
  const theta = (state.simTime / DAY_LENGTH) * 2 * Math.PI;
  const sinv = Math.sin(theta);
  const day = sinv > 0;
  const solar = Math.max(0, sinv);                 // 0..1 = solkraftens andel
  const lerp = (a, b, t) => Math.round(a + (b - a) * t);
  const mix = (c1, c2, t) => `rgb(${lerp(c1[0],c2[0],t)},${lerp(c1[1],c2[1],t)},${lerp(c1[2],c2[2],t)})`;

  dctx.clearRect(0, 0, W, H);
  // himmelsgradient
  const g = dctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, day ? mix([18,26,50],[70,120,200], solar) : '#0c1024');
  g.addColorStop(1, day ? mix([20,26,44],[225,150,90], solar) : '#12162c');
  dctx.fillStyle = g; dctx.fillRect(0, 0, W, H);

  // bågens bana
  dctx.strokeStyle = 'rgba(255,255,255,0.10)'; dctx.lineWidth = 1; dctx.beginPath();
  for (let i = 0; i <= 24; i++) { const t = i/24, x = lx + t*(rx-lx), y = horizon - Math.sin(t*Math.PI)*peak; i ? dctx.lineTo(x,y) : dctx.moveTo(x,y); }
  dctx.stroke();
  // horisont
  dctx.strokeStyle = 'rgba(255,255,255,0.18)'; dctx.beginPath(); dctx.moveTo(8, horizon); dctx.lineTo(W-8, horizon); dctx.stroke();

  // sol/måne-position (vandrar vänster→höger varje halvdygn)
  const across = (((theta % Math.PI) + Math.PI) % Math.PI) / Math.PI;
  const bx = lx + across * (rx - lx);
  const by = horizon - Math.abs(sinv) * peak;
  if (day) {
    dctx.save(); dctx.globalCompositeOperation = 'lighter';
    dctx.fillStyle = `rgba(255,205,70,${0.25 + solar*0.45})`; dctx.beginPath(); dctx.arc(bx, by, 10, 0, 7); dctx.fill();
    dctx.restore();
    dctx.fillStyle = '#ffd24d'; dctx.beginPath(); dctx.arc(bx, by, 5, 0, 7); dctx.fill();
    dctx.strokeStyle = '#ffd24d'; dctx.lineWidth = 1;
    for (let a = 0; a < 8; a++) { const an = a/8*Math.PI*2; dctx.beginPath(); dctx.moveTo(bx+Math.cos(an)*7, by+Math.sin(an)*7); dctx.lineTo(bx+Math.cos(an)*9.5, by+Math.sin(an)*9.5); dctx.stroke(); }
  } else {
    dctx.fillStyle = '#cdd6ea'; dctx.beginPath(); dctx.arc(bx, by, 5, 0, 7); dctx.fill();
  }

  // etiketter
  dctx.font = 'bold 9px monospace'; dctx.textBaseline = 'middle';
  dctx.textAlign = 'left'; dctx.fillStyle = 'rgba(200,212,232,0.7)'; dctx.fillText('DYGN', 8, 9);
  dctx.textAlign = 'right'; dctx.fillStyle = day ? '#ffe6a0' : '#9fb0d0';
  dctx.fillText((day ? 'SOL ' : 'NATT ') + Math.round(solar*100) + '%', W - 8, 9);
}
function drawHover() {
  if (!state.hover) return;
  const { row, col } = state.hover, x = col * CELL, y = row * CELL, t = state.tool;
  let ok = true;
  if (t.category === 'plant') ok = inBuildZone(col) && !isObstacle(row, col) && !nodeAt(row, col);
  else if (t.category === 'tower') {
    const ex = nodeAt(row, col);
    ok = !isObstacle(row, col) && col !== state.sc.cols - 1 && (!ex || (ex.kind === 'tower' && ex.key !== t.key))
      && !(nearCommunityCell(row, col) && !LOW_TOWERS.includes(t.key));
  } else if (t.category === 'battery' || t.category === 'lab')
    ok = !isObstacle(row, col) && !nodeAt(row, col) && col !== state.sc.cols - 1;
  ctx.strokeStyle = ok ? 'rgba(120,200,255,0.5)' : 'rgba(255,90,90,0.5)';
  ctx.lineWidth = 2; ctx.strokeRect(x + 1, y + 1, CELL - 2, CELL - 2);
}
function drawFlash() {
  if (performance.now() > flashTimer) return;
  ctx.fillStyle = 'rgba(0,0,0,0.78)'; ctx.fillRect(0, canvas.height - 34, canvas.width, 34);
  ctx.fillStyle = '#ffd24d'; ctx.font = '13px monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(flashMsg, canvas.width / 2, canvas.height - 17);
}

/* ---------- Scenarioflikar ---------- */
function buildScenarioTabs() {
  const tabs = document.getElementById('scenarioTabs');
  SCENARIOS.forEach((sc, i) => {
    const b = document.createElement('button');
    b.className = 'tab'; b.textContent = sc.id; b.title = sc.name;
    b.onclick = () => {
      if (!scenarioUnlocked(i)) { Sound.sfx.error(); flash('Klara föregående bana först.'); return; }
      Sound.sfx.click(); saveState(); startScenario(i); updateTabs(i); saveState();
    };
    if (i === 0) b.classList.add('active');
    tabs.appendChild(b);
  });
  updateTabs(0);
}

/* ---------- Wire UI ---------- */
document.getElementById('btnNew').onclick = () => { if (!hasSave() || confirm('Starta nytt spel? Detta skriver över din sparfil.')) newGame(); };
document.getElementById('btnContinue').onclick = () => { if (loadState()) enterGame(); else flash('Ingen sparfil hittades.'); };
document.getElementById('btnExport').onclick = exportSave;
document.getElementById('btnImport').onclick = () => document.getElementById('fileInput').click();
document.getElementById('fileInput').onchange = e => { if (e.target.files[0]) importSave(e.target.files[0]); };
document.getElementById('btnSave').onclick = () => { saveState(); flash('Sparat.'); };
document.getElementById('btnMenu').onclick = openMenu;
document.getElementById('techClose').onclick = closeTechTree;

/* Ljud: mute-knapp + initiering vid första interaktion (autoplay-policy) */
const MUTE_KEY = 'wattthef_mute';
let prefMuted = false; try { prefMuted = localStorage.getItem(MUTE_KEY) === '1'; } catch (e) {}
Sound.setMuted(prefMuted);
const muteBtn = document.getElementById('btnMute');
muteBtn.textContent = prefMuted ? '🔇' : '🔊';
muteBtn.onclick = () => {
  const m = !Sound.isMuted();
  Sound.setMuted(m);
  muteBtn.textContent = m ? '🔇' : '🔊';
  try { localStorage.setItem(MUTE_KEY, m ? '1' : '0'); } catch (e) {}
  if (!m) { Sound.init(); Sound.resume(); if (document.getElementById('startScreen').style.display !== 'none') Sound.startMusic(); }
};
let audioReady = false;
function ensureAudio() {
  if (audioReady) return; audioReady = true;
  Sound.init(); Sound.resume();
  if (!Sound.isMuted() && document.getElementById('startScreen').style.display !== 'none') Sound.startMusic();
}
window.addEventListener('pointerdown', ensureAudio);

/* ---------- Init ---------- */
buildScenarioTabs();
refreshContinue();
setInterval(() => { if (gameStarted && !paused) saveState(); }, 8000);
requestAnimationFrame(draw);
