/* =========================================================================
   WATT THE F*  — spelmotor (Canvas, top-down pixelstil)
   Intermittens, batterier, förluster, inkomst, förgrenad forskning,
   startskärm och sparfunktion.
   ========================================================================= */

const CELL = 44;
const BIG = 1e9;                 // ersätter Infinity (JSON-säkert)
const REFUND = 0.8;              // återbetalning vid rivning (80%)
const SAVE_KEY = 'wattthef_save_v1';
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
ctx.imageSmoothingEnabled = false;
const dayCanvas = document.getElementById('dayCanvas');
const dctx = dayCanvas ? dayCanvas.getContext('2d') : null;

let state = null;
let nodeSeq = 0, edgeSeq = 0;
let lastTime = performance.now();
let gameStarted = false, paused = true, techBuilt = false;

/* ---------- Global forskning (persisterar mellan banor + sparas) ---------- */
const tech = { science: 0, researched: new Set(['start']), unlocked: null };
const completed = new Set();   // klarade scenarioindex

function deriveUnlocks() {
  tech.unlocked = {
    plant:   new Set(STARTING_UNLOCKS.plant),
    tower:   new Set(STARTING_UNLOCKS.tower),
    line:    new Set(STARTING_UNLOCKS.line),
    battery: new Set(STARTING_UNLOCKS.battery),
    lab:     new Set(STARTING_UNLOCKS.lab),
    bundle:  new Set(STARTING_UNLOCKS.bundle),
  };
  TECH_TREE.forEach(n => { if (tech.researched.has(n.id)) n.unlocks.forEach(u => tech.unlocked[u.type].add(u.key)); });
}
deriveUnlocks();

const isUnlocked = (t, k) => tech.unlocked[t].has(k);
const techById = id => TECH_TREE.find(n => n.id === id);
const techFor = (type, key) => TECH_TREE.find(n => n.unlocks.some(u => u.type === type && u.key === key));
const nodeDone = id => tech.researched.has(id);
const canResearch = n => !nodeDone(n.id) && n.prereqs.every(p => nodeDone(p));

function techMsg(msg, ok) {
  const el = document.getElementById('techMsg');
  if (el) { el.textContent = msg; el.style.color = ok ? '#7dffb0' : '#ff9a9a'; }
}
function research(n) {
  if (nodeDone(n.id) || n.id === 'start') return;
  if (!canResearch(n)) { Sound.sfx.error(); return techMsg('Kräver först: ' + n.prereqs.filter(p => !nodeDone(p)).map(p => techById(p).name).join(', '), false); }
  if (tech.science < n.cost) { Sound.sfx.error(); return techMsg('För lite FP — behöver ' + n.cost + ' (har ' + Math.floor(tech.science) + ').', false); }
  tech.science -= n.cost;
  tech.researched.add(n.id);
  deriveUnlocks();
  buildPalette();
  renderTechTree();
  saveState();
  techMsg('Upplåst: ' + n.name + '!', true);
  flash('Upplåst: ' + n.name + '!');
  Sound.sfx.research();
}

/* ---------- Uppstart av scenario ---------- */
function startScenario(index) {
  const sc = SCENARIOS[index];
  const blocked = new Set(sc.blocked.map(b => `${b.row},${b.col}`));
  const nodes = [];
  sc.stations.forEach(st => nodes.push({
    id: ++nodeSeq, kind: 'station', key: 'station',
    row: st.row, col: sc.cols - 1, demand: st.demand, cap: BIG, span: BIG, cost: 0,
  }));
  state = {
    index, sc, blocked, nodes, edges: [],
    money: sc.startMoney, incomeNow: 0, lost: 0, researchPower: 0,
    tool: { category: 'plant', key: 'sol' }, bundle: 'simplex',
    pending: null, hover: null, produced: 0, transferred: 0,
    simTime: 0, sustainTimer: 0, won: false,
  };
  canvas.width = sc.cols * CELL;
  canvas.height = sc.rows * CELL;
  buildResearchPanel();
  buildPalette();
  updateHUD();
  document.getElementById('scenarioName').textContent = `${sc.id}. ${sc.name}`;
  document.getElementById('brief').textContent = sc.brief;
}

/* ---------- Hjälp ---------- */
const cellCenter = (r, c) => ({ x: c * CELL + CELL / 2, y: r * CELL + CELL / 2 });
const isBlocked = (r, c) => state.blocked.has(`${r},${c}`);
const inBuildZone = (c) => c < state.sc.buildCols;
const nodeAt = (r, c) => state.nodes.find(n => n.row === r && n.col === c);
const nodeById = (id) => state.nodes.find(n => n.id === id);
const cellDistance = (a, b) => Math.hypot(a.row - b.row, a.col - b.col);
function segmentCrossesBlocked(a, b) {
  const steps = Math.ceil(cellDistance(a, b) * 3);
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    if (isBlocked(Math.round(a.row + (b.row - a.row) * t), Math.round(a.col + (b.col - a.col) * t))) return true;
  }
  return false;
}

/* ---------- Tidssimulering ---------- */
function tick(dt) {
  const connected = new Set();
  state.edges.forEach(e => { connected.add(e.a); connected.add(e.b); });
  let producedConnected = 0;
  state.nodes.forEach(n => {
    if (n.kind === 'plant') {
      n.currentOutput = plantInstantOutput(n.key, state.simTime, n.id);
      if (connected.has(n.id)) producedConnected += n.currentOutput;
    }
  });
  const r = simulateTick(state.nodes, state.edges, dt);
  state.produced = producedConnected;
  state.transferred = r.delivered;
  state.lost = r.lost;
  state.researchPower = r.researchPower;
  state.edges.forEach(e => { e.flow = r.edgeFlow.get(e.id) || 0; });

  tech.science += r.researchPower * RESEARCH_RATE * dt;

  state.incomeNow = r.delivered * state.sc.incomeRate;
  state.money += state.incomeNow * dt;

  if (r.delivered >= state.sc.target - 0.5) state.sustainTimer += dt;
  else state.sustainTimer = Math.max(0, state.sustainTimer - dt * 0.7);
  if (state.sustainTimer >= state.sc.requiredSustain && !state.won) {
    state.won = true; completed.add(state.index); updateTabs(); Sound.sfx.win(); saveState();
  }

  state.simTime += dt;
  Sound.setFlow(Math.min(1, state.transferred / Math.max(1, state.sc.target)));
  updateHUD();
  updateResearchPanel();
}

/* ---------- Bygg / riv ---------- */
function recomputeEdgeCaps(nodeId) {
  state.edges.forEach(e => {
    if (e.a === nodeId || e.b === nodeId) {
      const a = nodeById(e.a), b = nodeById(e.b);
      e.cap = segmentCapacity(e.line, a.cap, b.cap, e.bundle || 1);
    }
  });
}
// Max bunt en nod tillåter: torn enligt klass, övriga noder begränsar inte (triplex)
function nodeBundleLimit(n) { return n.kind === 'tower' ? (TOWERS[n.key].bundle || 1) : 3; }

function tryPlace(row, col) {
  const t = state.tool;
  if (t.category === 'plant') {
    if (!inBuildZone(col)) return flash('Kraftverk byggs bara i produktionszonen (grön).');
    if (isBlocked(row, col) || nodeAt(row, col)) return;
    const p = PLANTS[t.key];
    if (state.money < p.cost) return flash('Inte råd.');
    state.money -= p.cost;
    state.nodes.push({ id: ++nodeSeq, kind: 'plant', key: t.key, row, col,
      output: p.output, currentOutput: 0, cap: BIG, span: BIG, cost: p.cost });
    Sound.sfx.place();
    return;
  }
  if (isBlocked(row, col)) return;
  if (col === state.sc.cols - 1) return flash('Högerkanten är reserverad för stationer.');
  const existing = nodeAt(row, col);

  if (t.category === 'tower') {
    const tw = TOWERS[t.key];
    if (existing) {
      if (existing.kind !== 'tower' || existing.key === t.key) return;   // ersätt bara torn av annan typ
      const net = tw.cost - REFUND * existing.cost;                       // betala mellanskillnaden
      if (state.money < net) return flash('Inte råd.');
      state.money -= net;
      existing.key = t.key; existing.cap = tw.capacity; existing.span = tw.span; existing.cost = tw.cost;
      recomputeEdgeCaps(existing.id);
      Sound.sfx.place();
      return;
    }
    if (state.money < tw.cost) return flash('Inte råd.');
    state.money -= tw.cost;
    state.nodes.push({ id: ++nodeSeq, kind: 'tower', key: t.key, row, col, cap: tw.capacity, span: tw.span, cost: tw.cost });
    Sound.sfx.place();
  } else if (t.category === 'battery') {
    if (existing) return;
    const bt = BATTERIES[t.key]; if (state.money < bt.cost) return flash('Inte råd.');
    state.money -= bt.cost;
    state.nodes.push({ id: ++nodeSeq, kind: 'battery', key: t.key, row, col, capacity: bt.capacity, soc: 0,
      chargeRate: bt.chargeRate, dischargeRate: bt.dischargeRate, cap: bt.cap, span: bt.span, cost: bt.cost });
    Sound.sfx.place();
  } else if (t.category === 'lab') {
    if (existing) return;
    const lb = LABS[t.key]; if (state.money < lb.cost) return flash('Inte råd.');
    state.money -= lb.cost;
    state.nodes.push({ id: ++nodeSeq, kind: 'research', key: t.key, row, col, demand: lb.demand, cap: lb.cap, span: lb.span, cost: lb.cost });
    Sound.sfx.place();
  }
}
function firstUnlockedLine() { return Object.keys(LINES).find(k => isUnlocked('line', k)) || 'jarn'; }

function tryConnect(target) {
  if (!state.pending) { state.pending = target.id; return; }
  if (state.pending === target.id) { state.pending = null; return; }
  const a = nodeById(state.pending), b = target; state.pending = null;
  if (!a || !b) return;
  const lineKey = state.tool.category === 'line' ? state.tool.key : firstUnlockedLine();
  const line = LINES[lineKey];
  const existing = state.edges.find(e => (e.a === a.id && e.b === b.id) || (e.a === b.id && e.b === a.id));
  const dist = existing ? existing.len : cellDistance(a, b);
  const maxAllowed = Math.min(line.maxLen, a.span, b.span);
  if (dist > maxAllowed) return flash(`För långt: ${dist.toFixed(1)} > max ${maxAllowed} för ${line.name} + tornen.`);

  // bunt: vald nivå klampad mot tornens klass
  const selKey = isUnlocked('bundle', state.bundle) ? state.bundle : 'simplex';
  const wanted = bundleMultByKey(selKey);
  const bundle = Math.min(wanted, nodeBundleLimit(a), nodeBundleLimit(b));
  if (bundle < wanted) flash(`Tornen klarar bara ${['', 'simplex', 'duplex', 'triplex'][bundle]}.`);

  if (existing) {
    if (existing.line === lineKey && (existing.bundle || 1) === bundle) return;   // identiskt – ingen åtgärd
    const newCost = Math.ceil(dist) * line.cost * bundle;
    const net = newCost - REFUND * existing.cost;
    if (state.money < net) return flash('Inte råd.');
    state.money -= net;
    existing.line = lineKey; existing.bundle = bundle; existing.cost = newCost;
    existing.cap = segmentCapacity(lineKey, a.cap, b.cap, bundle);
    Sound.sfx.line();
    return;
  }

  if (segmentCrossesBlocked(a, b)) return flash('Linan korsar ett berg.');
  const cost = Math.ceil(dist) * line.cost * bundle;
  if (state.money < cost) return flash(`Inte råd (${cost} kr).`);
  state.money -= cost;
  state.edges.push({ id: ++edgeSeq, a: a.id, b: b.id, line: lineKey, bundle, len: dist,
    cap: segmentCapacity(lineKey, a.cap, b.cap, bundle), cost, flow: 0 });
  Sound.sfx.line();
}

function eraseAt(row, col, mx, my) {
  const n = nodeAt(row, col);
  if (n) {
    if (n.kind === 'station') return flash('Stationer kan inte tas bort.');
    state.money += n.cost * REFUND;
    state.edges = state.edges.filter(e => { if (e.a === n.id || e.b === n.id) { state.money += e.cost * REFUND; return false; } return true; });
    state.nodes = state.nodes.filter(x => x.id !== n.id);
    if (state.pending === n.id) state.pending = null;
    Sound.sfx.erase();
    return;
  }
  let best = null, bestD = 12;
  state.edges.forEach(e => {
    const pa = cellCenter(nodeById(e.a).row, nodeById(e.a).col), pb = cellCenter(nodeById(e.b).row, nodeById(e.b).col);
    const d = distToSegment(mx, my, pa, pb); if (d < bestD) { bestD = d; best = e; }
  });
  if (best) { state.money += best.cost * REFUND; state.edges = state.edges.filter(e => e.id !== best.id); Sound.sfx.erase(); }
}
function distToSegment(px, py, a, b) {
  const dx = b.x - a.x, dy = b.y - a.y, len2 = dx * dx + dy * dy || 1;
  let t = Math.max(0, Math.min(1, ((px - a.x) * dx + (py - a.y) * dy) / len2));
  return Math.hypot(px - (a.x + t * dx), py - (a.y + t * dy));
}

/* ---------- Inmatning ---------- */
function eventCell(e) {
  const rect = canvas.getBoundingClientRect();
  const mx = (e.clientX - rect.left) * (canvas.width / rect.width);
  const my = (e.clientY - rect.top) * (canvas.height / rect.height);
  return { mx, my, col: Math.floor(mx / CELL), row: Math.floor(my / CELL) };
}
canvas.addEventListener('mousemove', e => {
  if (!state) return;
  const { row, col } = eventCell(e);
  state.hover = (row >= 0 && row < state.sc.rows && col >= 0 && col < state.sc.cols) ? { row, col } : null;
});
canvas.addEventListener('contextmenu', e => { e.preventDefault(); if (!state || paused) return; const { row, col, mx, my } = eventCell(e); eraseAt(row, col, mx, my); });
canvas.addEventListener('click', e => {
  if (!state || paused) return;
  const { row, col, mx, my } = eventCell(e);
  if (row < 0 || row >= state.sc.rows || col < 0 || col >= state.sc.cols) return;
  if (state.tool.category === 'line') { const n = nodeAt(row, col); if (n) tryConnect(n); else flash('Klicka på en nod för att dra lina.'); }
  else if (state.tool.category === 'erase') eraseAt(row, col, mx, my);
  else tryPlace(row, col);
});
window.addEventListener('keydown', e => {
  if (!gameStarted) return;
  if (e.key === 'Escape') {
    if (document.getElementById('techTree').style.display === 'flex') return closeTechTree();
    if (state) state.pending = null;
  }
  if ((e.key === 'r' || e.key === 'R') && state && !paused) startScenario(state.index);
});

/* ---------- HUD ---------- */
let flashTimer = 0, flashMsg = '';
function flash(msg) { flashMsg = msg; flashTimer = performance.now() + 2400; }
function updateHUD() {
  document.getElementById('money').textContent = Math.floor(state.money);
  document.getElementById('income').textContent = '+' + state.incomeNow.toFixed(1);
  document.getElementById('produced').textContent = Math.round(state.produced);
  document.getElementById('transferred').textContent = Math.round(state.transferred);
  document.getElementById('target').textContent = state.sc.target;
  document.getElementById('lost').textContent = Math.round(state.lost);
  document.getElementById('progressFill').style.width = Math.min(100, (state.transferred / state.sc.target) * 100) + '%';
  document.getElementById('stabilityFill').style.width = Math.min(100, (state.sustainTimer / state.sc.requiredSustain) * 100) + '%';
  document.getElementById('winBanner').style.display = state.won ? 'flex' : 'none';
}

/* ---------- Forskningspanel (sidofält) ---------- */
function buildResearchPanel() {
  const el = document.getElementById('research');
  el.innerHTML = `<div class="pal-group-title">Forskning</div>
    <div class="res-row">FP: <b id="sciVal">0</b></div>
    <button class="res-btn" id="openTech">⚛ Forskningsträd</button>`;
  document.getElementById('openTech').onclick = openTechTree;
}
function updateResearchPanel() { const s = document.getElementById('sciVal'); if (s) s.textContent = Math.floor(tech.science); }

/* ---------- Palett ---------- */
function buildPalette() {
  const pal = document.getElementById('palette'); pal.innerHTML = '';
  const group = (title, items, type, stats) => {
    const entries = Object.entries(items).filter(([key]) => isUnlocked(type, key));
    if (entries.length === 0) return;          // dölj hela gruppen om inget är upplåst än
    const h = document.createElement('div'); h.className = 'pal-group-title'; h.textContent = title; pal.appendChild(h);
    entries.forEach(([key, v]) => {
      const btn = document.createElement('button');
      btn.className = 'pal-btn'; btn.dataset.cat = type; btn.dataset.key = key;
      btn.innerHTML = `<span class="sw" style="background:${v.color}"></span><span class="pal-name">${v.name}</span><span class="pal-stats">${stats(v)}</span>`;
      btn.onclick = () => { Sound.sfx.click(); state.tool = { category: type, key }; state.pending = null; highlight(); };
      pal.appendChild(btn);
    });
  };
  group('Kraftverk', PLANTS, 'plant', v => `${v.output}W${v.variable ? '*' : ''} · ${v.cost}kr`);
  group('Torn', TOWERS, 'tower', v => `${v.capacity}W · ${v.span}c · ${v.cost}kr`);
  group('Linor', LINES, 'line', v => `${v.capacity}W · ${v.maxLen}c · ${Math.round(v.loss*100)}%/c`);
  // Bunt-väljare (visas först när duplex/triplex forskats fram)
  const bundleKeys = Object.keys(BUNDLES).filter(k => isUnlocked('bundle', k));
  if (bundleKeys.length > 1) {
    const bh = document.createElement('div'); bh.className = 'pal-group-title'; bh.textContent = 'Bunt'; pal.appendChild(bh);
    bundleKeys.forEach(k => {
      const v = BUNDLES[k];
      const btn = document.createElement('button');
      btn.className = 'pal-btn'; btn.dataset.bundle = k;
      btn.innerHTML = `<span class="sw" style="background:#3a5a8a"></span><span class="pal-name">${v.name}</span><span class="pal-stats">×${v.mult} kap · /${v.mult} förlust</span>`;
      btn.onclick = () => { Sound.sfx.click(); state.bundle = k; highlight(); };
      pal.appendChild(btn);
    });
  }
  group('Lager', BATTERIES, 'battery', v => `${(v.capacity/1000).toFixed(1)}kWs · ${v.cost}kr`);
  group('Forskning', LABS, 'lab', v => `−${v.demand}W · ${v.cost}kr`);
  const h = document.createElement('div'); h.className = 'pal-group-title'; h.textContent = 'Verktyg'; pal.appendChild(h);
  const erase = document.createElement('button');
  erase.className = 'pal-btn'; erase.dataset.cat = 'erase'; erase.dataset.key = 'erase';
  erase.innerHTML = `<span class="sw" style="background:#a33"></span><span class="pal-name">Riv</span><span class="pal-stats">återbetalar</span>`;
  erase.onclick = () => { state.tool = { category: 'erase', key: 'erase' }; state.pending = null; highlight(); };
  pal.appendChild(erase);
  highlight();
}
function highlight() {
  document.querySelectorAll('.pal-btn').forEach(b => {
    if (b.dataset.bundle) b.classList.toggle('active', b.dataset.bundle === state.bundle);
    else b.classList.toggle('active', b.dataset.cat === state.tool.category && b.dataset.key === state.tool.key);
  });
}

/* ---------- Forskningsträd-overlay ---------- */
const T_SPX = 160, T_SPY = 84, T_PAD = 20, T_W = 132, T_H = 64;
function tpos(n) { return { x: T_PAD + n.tier * T_SPX, y: T_PAD + n.row * T_SPY }; }
// Synlig (utforskad) = forskad ELLER har minst en forskad förkunskap (frontlinjen)
function techVisible(n) { return nodeDone(n.id) || n.prereqs.some(p => nodeDone(p)); }

function renderTechTree() {
  const nodesEl = document.getElementById('techNodes');
  const svg = document.getElementById('techEdges');
  nodesEl.innerHTML = ''; svg.innerHTML = '';
  let maxTier = 0, maxRow = 0;
  TECH_TREE.forEach(n => { maxTier = Math.max(maxTier, n.tier); maxRow = Math.max(maxRow, n.row); });
  const W = T_PAD * 2 + maxTier * T_SPX + T_W, H = T_PAD * 2 + maxRow * T_SPY + T_H;
  document.getElementById('techCanvasWrap').style.width = W + 'px';
  document.getElementById('techCanvasWrap').style.height = H + 'px';
  svg.setAttribute('width', W); svg.setAttribute('height', H);
  // kanter (dämpade in i dimman)
  TECH_TREE.forEach(n => {
    const p = tpos(n);
    n.prereqs.forEach(pr => {
      const q = tpos(techById(pr));
      const x1 = q.x + T_W, y1 = q.y + T_H / 2, x2 = p.x, y2 = p.y + T_H / 2, mx = (x1 + x2) / 2;
      const line = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      line.setAttribute('d', `M ${x1} ${y1} C ${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2}`);
      const dim = !techVisible(n);
      line.setAttribute('stroke', dim ? '#19202f' : '#2a3a5a');
      line.setAttribute('stroke-width', dim ? '1.5' : '2');
      if (dim) line.setAttribute('stroke-dasharray', '3 5');
      line.setAttribute('fill', 'none');
      svg.appendChild(line);
    });
  });
  // noder
  TECH_TREE.forEach(n => {
    const p = tpos(n);
    const div = document.createElement('div');
    div.id = 'tn_' + n.id; div.style.left = p.x + 'px'; div.style.top = p.y + 'px';
    if (!techVisible(n)) {
      div.className = 'tnode fog';
      div.innerHTML = `<div class="tn-fog">?</div>`;
    } else {
      let cls = 'tnode';
      if (n.id === 'start' || nodeDone(n.id)) cls += ' done';
      else if (canResearch(n)) cls += tech.science >= n.cost ? ' available' : ' poor';
      else cls += ' locked';
      if (n.id === 'start') cls += ' root';
      div.className = cls;
      const unlockTxt = n.unlocks.map(u => recipeName(u)).join(', ') || 'bas';
      div.innerHTML = `<div class="tn-name">${n.name}</div><div class="tn-unlock">${unlockTxt}</div><div class="tn-cost">${n.id==='start'?'start':n.cost+' FP'}</div>`;
      if (n.id !== 'start' && !nodeDone(n.id)) div.onclick = () => research(n);
    }
    nodesEl.appendChild(div);
  });
  const fp = document.getElementById('techFP'); if (fp) fp.textContent = Math.floor(tech.science);
}
function recipeName(u) {
  const map = { plant: PLANTS, tower: TOWERS, line: LINES, battery: BATTERIES, lab: LABS };
  return map[u.type][u.key]?.name || u.key;
}
function openTechTree() {
  techMsg('', true);
  renderTechTree();
  document.getElementById('techTree').style.display = 'flex';
  paused = true;
}
function closeTechTree() { document.getElementById('techTree').style.display = 'none'; if (gameStarted) paused = false; }

/* ---------- Spara / ladda ---------- */
function serialize() {
  return { v: 1, science: tech.science, researched: [...tech.researched], completed: [...completed],
    scenarioIndex: state.index, money: state.money, simTime: state.simTime,
    sustainTimer: state.sustainTimer, won: state.won,
    nodes: state.nodes, edges: state.edges, nodeSeq, edgeSeq };
}
function saveState() { try { if (state) localStorage.setItem(SAVE_KEY, JSON.stringify(serialize())); } catch (e) {} }
function hasSave() { try { return !!localStorage.getItem(SAVE_KEY); } catch (e) { return false; } }
function applySave(s) {
  tech.science = s.science || 0;
  tech.researched = new Set(s.researched && s.researched.length ? s.researched : ['start']);
  completed.clear(); (s.completed || []).forEach(i => completed.add(i));
  deriveUnlocks();
  startScenario(s.scenarioIndex || 0);
  state.money = s.money; state.simTime = s.simTime || 0; state.sustainTimer = s.sustainTimer || 0; state.won = !!s.won;
  state.nodes = s.nodes; state.edges = s.edges; nodeSeq = s.nodeSeq || nodeSeq; edgeSeq = s.edgeSeq || edgeSeq;
  buildPalette(); updateHUD(); updateResearchPanel(); techBuilt = false;
  updateTabs(s.scenarioIndex || 0);
}
function loadState() {
  try { const raw = localStorage.getItem(SAVE_KEY); if (!raw) return false; applySave(JSON.parse(raw)); return true; }
  catch (e) { return false; }
}
function exportSave() {
  if (!state) return;
  const blob = new Blob([JSON.stringify(serialize(), null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = 'wattthef-save.json'; a.click();
  URL.revokeObjectURL(a.href);
}
function importSave(file) {
  const reader = new FileReader();
  reader.onload = () => { try { applySave(JSON.parse(reader.result)); enterGame(); flash('Sparfil laddad.'); } catch (e) { flash('Ogiltig sparfil.'); } };
  reader.readAsText(file);
}

/* ---------- Start / meny ---------- */
function newGame() {
  tech.science = 0; tech.researched = new Set(['start']); completed.clear(); deriveUnlocks(); techBuilt = false;
  startScenario(0);
  updateTabs(0);
  enterGame(); saveState();
}
function enterGame() {
  gameStarted = true; paused = false;
  document.getElementById('startScreen').style.display = 'none';
  document.getElementById('techTree').style.display = 'none';
  Sound.stopMusic();
}
function openMenu() { saveState(); paused = true; Sound.setFlow(0); Sound.startMusic(); document.getElementById('startScreen').style.display = 'flex'; refreshContinue(); }
function refreshContinue() { document.getElementById('btnContinue').disabled = !hasSave(); }

/* En bana är upplåst om den är den första eller om föregående är klarad */
function scenarioUnlocked(i) { return i === 0 || completed.has(i - 1); }

/* Uppdatera scenarioflikar: aktiv + klarat-bock + lås */
function updateTabs(activeIndex) {
  const tabs = document.querySelectorAll('.tab');
  tabs.forEach((tab, i) => {
    const done = completed.has(i);
    const locked = !scenarioUnlocked(i);
    tab.classList.toggle('done', done);
    tab.classList.toggle('locked', locked);
    tab.classList.toggle('active', activeIndex !== undefined ? i === activeIndex : tab.classList.contains('active'));
    tab.textContent = locked ? '🔒' : SCENARIOS[i].id + (done ? '✓' : '');
  });
}

/* ---------- Rendering ---------- */
function draw(time) {
  const dt = Math.min(0.05, (time - lastTime) / 1000); lastTime = time;
  requestAnimationFrame(draw);
  if (!state || paused) { Sound.setFlow(0); return; }
  tick(dt);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawTerrain(); drawEdges(time); drawPendingPreview(); drawNodes(); drawDayNight(); drawHover(); drawFlash();
  drawDayWidget();
}
function drawTerrain() {
  const { sc } = state;
  for (let r = 0; r < sc.rows; r++) for (let c = 0; c < sc.cols; c++) {
    const x = c * CELL, y = r * CELL;
    let fill = '#10151f'; if (inBuildZone(c)) fill = '#10211a'; if (c === sc.cols - 1) fill = '#1a1422';
    ctx.fillStyle = fill; ctx.fillRect(x, y, CELL, CELL);
    ctx.strokeStyle = 'rgba(255,255,255,0.03)'; ctx.strokeRect(x + 0.5, y + 0.5, CELL, CELL);
  }
  ctx.fillStyle = 'rgba(80,200,140,0.35)'; ctx.font = '11px monospace';
  ctx.save(); ctx.translate(10, sc.rows * CELL / 2); ctx.rotate(-Math.PI / 2);
  ctx.textAlign = 'center'; ctx.fillText('PRODUKTIONSZON', 0, 0); ctx.restore();
  state.blocked.forEach(k => { const [r, c] = k.split(',').map(Number); drawMountain(c * CELL, r * CELL); });
}
function drawMountain(x, y) {
  ctx.fillStyle = '#2a2f3a'; ctx.fillRect(x + 3, y + 3, CELL - 6, CELL - 6);
  ctx.fillStyle = '#3a4150'; ctx.beginPath();
  ctx.moveTo(x + 7, y + CELL - 8); ctx.lineTo(x + CELL / 2, y + 9); ctx.lineTo(x + CELL - 7, y + CELL - 8); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#dfe6f0'; ctx.beginPath();
  ctx.moveTo(x + CELL / 2 - 5, y + 17); ctx.lineTo(x + CELL / 2, y + 9); ctx.lineTo(x + CELL / 2 + 5, y + 17); ctx.closePath(); ctx.fill();
}
function drawEdges(time) {
  state.edges.forEach(e => {
    const a = nodeById(e.a), b = nodeById(e.b);
    const pa = cellCenter(a.row, a.col), pb = cellCenter(b.row, b.col);
    const active = Math.abs(e.flow) > 0.001;
    const bundle = e.bundle || 1;
    const dx = pb.x - pa.x, dy = pb.y - pa.y, len = Math.hypot(dx, dy) || 1;
    const px = -dy / len, py = dx / len;
    ctx.lineWidth = 2.5; ctx.strokeStyle = active ? '#1d3a55' : LINES[e.line].color; ctx.globalAlpha = active ? 1 : 0.55;
    for (let i = 0; i < bundle; i++) {
      const off = (i - (bundle - 1) / 2) * 3.2;
      ctx.beginPath(); ctx.moveTo(pa.x + px*off, pa.y + py*off); ctx.lineTo(pb.x + px*off, pb.y + py*off); ctx.stroke();
    }
    ctx.globalAlpha = 1;
    if (active) drawFlow(pa, pb, e, time);
  });
}
function drawFlow(pa, pb, e, time) {
  const dir = e.flow >= 0 ? 1 : -1;
  const from = dir > 0 ? pa : pb, to = dir > 0 ? pb : pa;
  const dx = to.x - from.x, dy = to.y - from.y, len = Math.hypot(dx, dy) || 1;
  const px = -dy / len, py = dx / len, load = Math.min(1, Math.abs(e.flow) / e.cap);
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.strokeStyle = `rgba(40,120,255,${0.10 + load * 0.15})`; ctx.lineWidth = 8;
  ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.lineTo(pb.x, pb.y); ctx.stroke();
  const speed = 90, spacing = 26, phase = (time / 1000 * speed) % spacing;
  ctx.strokeStyle = `rgba(120,200,255,${0.5 + load * 0.4})`; ctx.lineWidth = 2.5;
  ctx.setLineDash([7, spacing - 7]); ctx.lineDashOffset = -phase;
  ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke(); ctx.setLineDash([]);
  const boltHead = (time / 1000 * speed * 1.4) % (len + 40) - 20, segs = 6, reach = 28;
  ctx.strokeStyle = 'rgba(180,230,255,0.7)'; ctx.lineWidth = 1.4; ctx.beginPath();
  for (let i = 0; i <= segs; i++) {
    const along = boltHead + (i / segs) * reach; if (along < 0 || along > len) continue;
    const t = along / len, jit = Math.sin(i * 12.9 + time / 60) * 4 * (1 - load * 0.3);
    const x = from.x + dx * t + px * jit, y = from.y + dy * t + py * jit;
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.stroke(); ctx.restore();
}
function drawPendingPreview() {
  if (!state.pending || !state.hover) return;
  const a = nodeById(state.pending); if (!a) return;
  const pa = cellCenter(a.row, a.col), pb = cellCenter(state.hover.row, state.hover.col);
  const lineKey = state.tool.category === 'line' ? state.tool.key : firstUnlockedLine();
  const line = LINES[lineKey], tgt = { row: state.hover.row, col: state.hover.col }, dist = cellDistance(a, tgt);
  const ok = dist <= Math.min(line.maxLen, a.span) && !segmentCrossesBlocked(a, tgt);
  ctx.strokeStyle = ok ? 'rgba(120,200,255,0.8)' : 'rgba(255,90,90,0.8)';
  ctx.lineWidth = 2; ctx.setLineDash([5, 5]);
  ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.lineTo(pb.x, pb.y); ctx.stroke(); ctx.setLineDash([]);
}
function drawNodes() {
  state.nodes.forEach(n => {
    const { x, y } = cellCenter(n.row, n.col);
    if (n.kind === 'plant') drawPlant(x, y, n);
    else if (n.kind === 'tower') drawTower(x, y, n);
    else if (n.kind === 'battery') drawBattery(x, y, n);
    else if (n.kind === 'research') drawLab(x, y, n);
    else drawStation(x, y, n);
    if (n.id === state.pending) { ctx.strokeStyle = '#ffe14d'; ctx.lineWidth = 2; ctx.strokeRect(x - CELL/2 + 3, y - CELL/2 + 3, CELL - 6, CELL - 6); }
  });
}
function drawPlant(x, y, n) {
  const p = PLANTS[n.key], lit = (n.currentOutput || 0) > 1;
  ctx.fillStyle = '#0c0f16'; ctx.fillRect(x - 16, y - 16, 32, 32);
  ctx.fillStyle = lit ? p.color : '#3a3f48'; ctx.fillRect(x - 13, y - 13, 26, 26);
  ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(x - 13, y + 5, 26, 8);
  ctx.fillStyle = '#0c0f16'; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(n.key.slice(0, 3).toUpperCase(), x, y - 3); ctx.fillText(Math.round(n.currentOutput || 0) + 'W', x, y + 9);
}
function drawTower(x, y, n) {
  const t = TOWERS[n.key];
  ctx.strokeStyle = t.color; ctx.lineWidth = 2; ctx.beginPath();
  ctx.moveTo(x - 11, y + 12); ctx.lineTo(x, y - 13); ctx.lineTo(x + 11, y + 12);
  ctx.moveTo(x - 7, y + 1); ctx.lineTo(x + 7, y + 1); ctx.moveTo(x - 9, y + 7); ctx.lineTo(x + 9, y + 7);
  ctx.moveTo(x - 4, y - 6); ctx.lineTo(x + 4, y - 6); ctx.stroke();
  ctx.fillStyle = t.color; ctx.beginPath(); ctx.arc(x, y - 13, 2.2, 0, Math.PI * 2); ctx.fill();
}
function drawBattery(x, y, n) {
  const bt = BATTERIES[n.key];
  ctx.fillStyle = '#0c0f16'; ctx.fillRect(x - 14, y - 16, 28, 32);
  ctx.strokeStyle = bt.color; ctx.lineWidth = 2; ctx.strokeRect(x - 11, y - 13, 22, 26);
  ctx.fillStyle = '#2a3340'; ctx.fillRect(x - 9, y - 11, 18, 22);
  const soc = Math.max(0, Math.min(1, n.soc / n.capacity)), h = Math.round(22 * soc);
  ctx.fillStyle = bt.color; ctx.fillRect(x - 9, y + 11 - h, 18, h);
  ctx.fillStyle = bt.color; ctx.fillRect(x - 3, y - 16, 6, 3);
}
function drawLab(x, y, n) {
  const lb = LABS[n.key], active = (state.researchPower || 0) > 0;
  ctx.fillStyle = '#0c0f16'; ctx.fillRect(x - 15, y - 15, 30, 30);
  ctx.fillStyle = '#1c1430'; ctx.fillRect(x - 12, y - 12, 24, 24);
  ctx.strokeStyle = lb.color; ctx.lineWidth = 2; ctx.strokeRect(x - 12, y - 12, 24, 24);
  ctx.strokeStyle = active ? '#e6c2ff' : '#5a4a72'; ctx.lineWidth = 2; ctx.beginPath();
  ctx.moveTo(x - 4, y - 7); ctx.lineTo(x - 4, y - 1); ctx.lineTo(x - 8, y + 7); ctx.lineTo(x + 8, y + 7); ctx.lineTo(x + 4, y - 1); ctx.lineTo(x + 4, y - 7); ctx.stroke();
  if (active) { ctx.fillStyle = lb.color; ctx.beginPath(); ctx.arc(x, y + 3, 3, 0, Math.PI * 2); ctx.fill(); }
  ctx.fillStyle = '#b98cff'; ctx.font = 'bold 8px monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText('−' + lb.demand + 'W', x, y + 20);
}
function drawStation(x, y, n) {
  ctx.fillStyle = '#0c0f16'; ctx.fillRect(x - 16, y - 16, 32, 32);
  const met = state.transferred > 0;
  ctx.fillStyle = '#3a2a4a'; ctx.fillRect(x - 13, y - 13, 26, 26);
  ctx.fillStyle = met ? '#ffd24d' : '#5a4a2a';
  for (let i = 0; i < 3; i++) for (let j = 0; j < 2; j++) ctx.fillRect(x - 10 + i * 8, y - 9 + j * 9, 4, 5);
  ctx.fillStyle = '#c8d8f0'; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(n.demand + 'W', x, y + 21);
  ctx.fillStyle = '#7ec8ff'; ctx.beginPath();
  ctx.moveTo(x + 1, y - 8); ctx.lineTo(x - 4, y + 1); ctx.lineTo(x - 1, y + 1); ctx.lineTo(x - 3, y + 9); ctx.lineTo(x + 5, y - 2); ctx.lineTo(x + 1, y - 2); ctx.closePath(); ctx.fill();
}
function drawDayNight() {
  const daylight = Math.max(0, Math.sin((state.simTime / DAY_LENGTH) * 2 * Math.PI)), night = 1 - daylight;
  if (night > 0.01) { ctx.fillStyle = `rgba(8,12,30,${night * 0.4})`; ctx.fillRect(0, 0, canvas.width, canvas.height); }
}

// Liten dygnsindikator: sol/måne i en båge, höjden = solkraftens effekt just nu
function drawDayWidget() {
  if (!dctx || !state) return;
  const W = 132, H = 46, horizon = 33, peak = 22, lx = 14, rx = W - 14;
  const theta = (state.simTime / DAY_LENGTH) * 2 * Math.PI;
  const sinv = Math.sin(theta);
  const day = sinv > 0;
  const solar = Math.max(0, sinv);                 // 0..1 = solkraftens andel
  const lerp = (a, b, t) => Math.round(a + (b - a) * t);
  const mix = (c1, c2, t) => `rgb(${lerp(c1[0],c2[0],t)},${lerp(c1[1],c2[1],t)},${lerp(c1[2],c2[2],t)})`;

  dctx.clearRect(0, 0, W, H);
  // himmelsgradient
  const g = dctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, day ? mix([18,26,50],[70,120,200], solar) : '#0c1024');
  g.addColorStop(1, day ? mix([20,26,44],[225,150,90], solar) : '#12162c');
  dctx.fillStyle = g; dctx.fillRect(0, 0, W, H);

  // bågens bana
  dctx.strokeStyle = 'rgba(255,255,255,0.10)'; dctx.lineWidth = 1; dctx.beginPath();
  for (let i = 0; i <= 24; i++) { const t = i/24, x = lx + t*(rx-lx), y = horizon - Math.sin(t*Math.PI)*peak; i ? dctx.lineTo(x,y) : dctx.moveTo(x,y); }
  dctx.stroke();
  // horisont
  dctx.strokeStyle = 'rgba(255,255,255,0.18)'; dctx.beginPath(); dctx.moveTo(8, horizon); dctx.lineTo(W-8, horizon); dctx.stroke();

  // sol/måne-position (vandrar vänster→höger varje halvdygn)
  const across = (((theta % Math.PI) + Math.PI) % Math.PI) / Math.PI;
  const bx = lx + across * (rx - lx);
  const by = horizon - Math.abs(sinv) * peak;
  if (day) {
    dctx.save(); dctx.globalCompositeOperation = 'lighter';
    dctx.fillStyle = `rgba(255,205,70,${0.25 + solar*0.45})`; dctx.beginPath(); dctx.arc(bx, by, 10, 0, 7); dctx.fill();
    dctx.restore();
    dctx.fillStyle = '#ffd24d'; dctx.beginPath(); dctx.arc(bx, by, 5, 0, 7); dctx.fill();
    dctx.strokeStyle = '#ffd24d'; dctx.lineWidth = 1;
    for (let a = 0; a < 8; a++) { const an = a/8*Math.PI*2; dctx.beginPath(); dctx.moveTo(bx+Math.cos(an)*7, by+Math.sin(an)*7); dctx.lineTo(bx+Math.cos(an)*9.5, by+Math.sin(an)*9.5); dctx.stroke(); }
  } else {
    dctx.fillStyle = '#cdd6ea'; dctx.beginPath(); dctx.arc(bx, by, 5, 0, 7); dctx.fill();
  }

  // etiketter
  dctx.font = 'bold 9px monospace'; dctx.textBaseline = 'middle';
  dctx.textAlign = 'left'; dctx.fillStyle = 'rgba(200,212,232,0.7)'; dctx.fillText('DYGN', 8, 9);
  dctx.textAlign = 'right'; dctx.fillStyle = day ? '#ffe6a0' : '#9fb0d0';
  dctx.fillText((day ? 'SOL ' : 'NATT ') + Math.round(solar*100) + '%', W - 8, 9);
}
function drawHover() {
  if (!state.hover) return;
  const { row, col } = state.hover, x = col * CELL, y = row * CELL, t = state.tool;
  let ok = true;
  if (t.category === 'plant') ok = inBuildZone(col) && !isBlocked(row, col) && !nodeAt(row, col);
  else if (t.category === 'tower') {
    const ex = nodeAt(row, col);
    ok = !isBlocked(row, col) && col !== state.sc.cols - 1 && (!ex || (ex.kind === 'tower' && ex.key !== t.key));
  } else if (t.category === 'battery' || t.category === 'lab')
    ok = !isBlocked(row, col) && !nodeAt(row, col) && col !== state.sc.cols - 1;
  ctx.strokeStyle = ok ? 'rgba(120,200,255,0.5)' : 'rgba(255,90,90,0.5)';
  ctx.lineWidth = 2; ctx.strokeRect(x + 1, y + 1, CELL - 2, CELL - 2);
}
function drawFlash() {
  if (performance.now() > flashTimer) return;
  ctx.fillStyle = 'rgba(0,0,0,0.78)'; ctx.fillRect(0, canvas.height - 34, canvas.width, 34);
  ctx.fillStyle = '#ffd24d'; ctx.font = '13px monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(flashMsg, canvas.width / 2, canvas.height - 17);
}

/* ---------- Scenarioflikar ---------- */
function buildScenarioTabs() {
  const tabs = document.getElementById('scenarioTabs');
  SCENARIOS.forEach((sc, i) => {
    const b = document.createElement('button');
    b.className = 'tab'; b.textContent = sc.id; b.title = sc.name;
    b.onclick = () => {
      if (!scenarioUnlocked(i)) { Sound.sfx.error(); flash('Klara föregående bana först.'); return; }
      Sound.sfx.click(); saveState(); startScenario(i); updateTabs(i); saveState();
    };
    if (i === 0) b.classList.add('active');
    tabs.appendChild(b);
  });
  updateTabs(0);
}

/* ---------- Wire UI ---------- */
document.getElementById('btnNew').onclick = () => { if (!hasSave() || confirm('Starta nytt spel? Detta skriver över din sparfil.')) newGame(); };
document.getElementById('btnContinue').onclick = () => { if (loadState()) enterGame(); else flash('Ingen sparfil hittades.'); };
document.getElementById('btnExport').onclick = exportSave;
document.getElementById('btnImport').onclick = () => document.getElementById('fileInput').click();
document.getElementById('fileInput').onchange = e => { if (e.target.files[0]) importSave(e.target.files[0]); };
document.getElementById('btnSave').onclick = () => { saveState(); flash('Sparat.'); };
document.getElementById('btnMenu').onclick = openMenu;
document.getElementById('techClose').onclick = closeTechTree;

/* Ljud: mute-knapp + initiering vid första interaktion (autoplay-policy) */
const MUTE_KEY = 'wattthef_mute';
let prefMuted = false; try { prefMuted = localStorage.getItem(MUTE_KEY) === '1'; } catch (e) {}
Sound.setMuted(prefMuted);
const muteBtn = document.getElementById('btnMute');
muteBtn.textContent = prefMuted ? '🔇' : '🔊';
muteBtn.onclick = () => {
  const m = !Sound.isMuted();
  Sound.setMuted(m);
  muteBtn.textContent = m ? '🔇' : '🔊';
  try { localStorage.setItem(MUTE_KEY, m ? '1' : '0'); } catch (e) {}
  if (!m) { Sound.init(); Sound.resume(); if (document.getElementById('startScreen').style.display !== 'none') Sound.startMusic(); }
};
let audioReady = false;
function ensureAudio() {
  if (audioReady) return; audioReady = true;
  Sound.init(); Sound.resume();
  if (!Sound.isMuted() && document.getElementById('startScreen').style.display !== 'none') Sound.startMusic();
}
window.addEventListener('pointerdown', ensureAudio);

/* ---------- Init ---------- */
buildScenarioTabs();
refreshContinue();
setInterval(() => { if (gameStarted && !paused) saveState(); }, 8000);
requestAnimationFrame(draw);
