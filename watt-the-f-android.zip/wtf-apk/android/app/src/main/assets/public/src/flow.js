/* =========================================================================
   KRAFTNÄTET — flödessimulering med överföringsförluster
   Per tick (prioritet: stationer > forskning > lagring):
     1. Kraftverk -> stationer (max-flöde).
     2. Vid underskott: batterier laddar ur till stationer.
     3. Kraftverk/rest -> forskningslabb.
     4. Vid överskott: ladda batterier.
   Förluster: max-flödet dekomponeras i vägar; varje väg tappar
   summan av linsegmentens förluster (längd * materialets förlust/cell).
   ========================================================================= */

class FlowNet {
  constructor(n) {
    this.n = n;
    this.cap = Array.from({ length: n }, () => new Float64Array(n));
    this.adj = Array.from({ length: n }, () => []);
  }
  addArc(u, v, c) {
    if (c <= 0) return;
    if (this.cap[u][v] === 0 && this.cap[v][u] === 0) { this.adj[u].push(v); this.adj[v].push(u); }
    this.cap[u][v] += c;
  }
  augment(S, T) {
    let total = 0;
    const { n, cap, adj } = this;
    while (true) {
      const parent = new Int32Array(n).fill(-1);
      parent[S] = S;
      const q = [S]; let head = 0;
      while (head < q.length) {
        const u = q[head++];
        for (const v of adj[u]) {
          if (parent[v] === -1 && cap[u][v] > 1e-9) {
            parent[v] = u;
            if (v === T) { head = q.length; break; }
            q.push(v);
          }
        }
      }
      if (parent[T] === -1) break;
      let bn = Infinity;
      for (let v = T; v !== S; v = parent[v]) bn = Math.min(bn, cap[parent[v]][v]);
      for (let v = T; v !== S; v = parent[v]) { cap[parent[v]][v] -= bn; cap[v][parent[v]] += bn; }
      total += bn;
    }
    return total;
  }
}

function simulateTick(nodes, edges, dt) {
  const idx = new Map();
  nodes.forEach((nd, i) => idx.set(nd.id, i));
  const N = nodes.length + 2, S = nodes.length, T = nodes.length + 1;
  const net = new FlowNet(N);

  const orig = {};                     // "u,v" -> ursprunglig kapacitet
  const arc = (u, v, c) => { if (c > 0) { net.addArc(u, v, c); orig[u + ',' + v] = (orig[u + ',' + v] || 0) + c; } };

  const plantArcs = [], stationArcs = [], labArcs = [], batt = [];
  const lossMap = {};                  // "u,v" -> förlustfraktion för det linsegmentet

  nodes.forEach((nd, i) => {
    if (nd.kind === 'plant')    plantArcs.push({ nd, i });
    if (nd.kind === 'station')  stationArcs.push({ nd, i });
    if (nd.kind === 'research') labArcs.push({ nd, i });
    if (nd.kind === 'battery') {
      const space = Math.max(0, nd.capacity - nd.soc);
      batt.push({ nd, i,
        chargeAvail: Math.min(nd.chargeRate, space / dt),
        dischargeAvail: Math.min(nd.dischargeRate, nd.soc / dt) });
    }
  });

  // Linbågar + förlust per segment
  edges.forEach(e => {
    const u = idx.get(e.a), v = idx.get(e.b);
    if (u === undefined || v === undefined) return;
    arc(u, v, e.cap); arc(v, u, e.cap);
    const loss = Math.min(0.75, (LINES[e.line].loss || 0) * e.len / (e.bundle || 1));
    lossMap[u + ',' + v] = loss; lossMap[v + ',' + u] = loss;
  });

  // Källor (kraftverk)
  plantArcs.forEach(p => arc(S, p.i, p.nd.currentOutput || 0));

  // 1) Stationer
  stationArcs.forEach(s => arc(s.i, T, s.nd.demand || 0));
  net.augment(S, T);

  // Överskott på källsidan?
  let surplus = 0; plantArcs.forEach(p => { surplus += net.cap[S][p.i]; });

  // 2) Urladdning vid underskott
  if (surplus <= 1e-6) {
    const o = batt.map(b => { arc(S, b.i, b.dischargeAvail); return b.dischargeAvail; });
    net.augment(S, T);
    batt.forEach((b, k) => {
      const used = o[k] - net.cap[S][b.i];
      if (used > 1e-9) b.nd.soc = Math.max(0, b.nd.soc - used * dt);
    });
  }

  // 3) Forskningslabb (leftover kapacitet)
  labArcs.forEach(l => arc(l.i, T, l.nd.demand || 0));
  net.augment(S, T);

  // 4) Laddning vid överskott
  surplus = 0; plantArcs.forEach(p => { surplus += net.cap[S][p.i]; });
  if (surplus > 1e-6) {
    const o = batt.map(b => { arc(b.i, T, b.chargeAvail); return b.chargeAvail; });
    net.augment(S, T);
    batt.forEach((b, k) => {
      const used = o[k] - net.cap[b.i][T];
      if (used > 1e-9) b.nd.soc = Math.min(b.nd.capacity, b.nd.soc + used * dt);
    });
  }

  // --- Vägdekomposition för att applicera förluster ---
  // Fysiskt riktat flöde per båge (positivt i den bärande riktningen)
  const g = {};
  const gAdj = Array.from({ length: N }, () => []);
  const flowOf = (u, v) => Math.max(0, (orig[u + ',' + v] || 0) - net.cap[u][v]);
  for (let u = 0; u < N; u++) for (const v of net.adj[u]) {
    const f = flowOf(u, v);
    if (f > 1e-9) { g[u + ',' + v] = f; gAdj[u].push(v); }
  }
  const kindOf = i => (i < nodes.length ? nodes[i].kind : null);

  let deliveredStation = 0, rawStation = 0, deliveredLab = 0;
  const edgeFlow = new Map();

  // hitta väg S->T med DFS, dra av flöde, applicera förlust
  let guard = 0;
  while (guard++ < 20000) {
    const parent = new Int32Array(N).fill(-1);
    parent[S] = S;
    const stack = [S]; let found = false;
    while (stack.length) {
      const u = stack.pop();
      if (u === T) { found = true; break; }
      for (const v of gAdj[u]) {
        if (parent[v] === -1 && (g[u + ',' + v] || 0) > 1e-9) { parent[v] = u; stack.push(v); }
      }
    }
    if (!found || parent[T] === -1) break;

    // bygg väg
    const path = [];
    for (let v = T; v !== S; v = parent[v]) path.push(v);
    path.push(S); path.reverse();           // [S, ..., T]

    let phi = Infinity;
    for (let k = 0; k < path.length - 1; k++) phi = Math.min(phi, g[path[k] + ',' + path[k + 1]]);

    // förlust = summan av linsegmentens förluster i vägens inre
    let loss = 0;
    for (let k = 1; k < path.length - 2; k++) loss += (lossMap[path[k] + ',' + path[k + 1]] || 0);
    const eff = 1 - Math.min(0.75, loss);

    const sinkNode = path[path.length - 2];  // noden före T
    const sk = kindOf(sinkNode);
    if (sk === 'station') { deliveredStation += phi * eff; rawStation += phi; }
    else if (sk === 'research') { deliveredLab += phi * eff; }
    // (battery-charge sink: ignoreras här, soc redan uppdaterad)

    for (let k = 0; k < path.length - 1; k++) {
      const key = path[k] + ',' + path[k + 1];
      g[key] -= phi;
      if (g[key] <= 1e-9) g[key] = 0;
    }
  }

  // Nettoflöde per lina (för animering)
  edges.forEach(e => {
    const u = idx.get(e.a), v = idx.get(e.b);
    if (u === undefined || v === undefined) return;
    edgeFlow.set(e.id, flowOf(u, v) - flowOf(v, u));
  });

  return {
    delivered: deliveredStation,
    lost: rawStation - deliveredStation,
    researchPower: deliveredLab,
    edgeFlow,
  };
}
