/* =========================================================================
   WATT THE F* — ljud (Web Audio, helt syntetiserat, inga filer)
   Exponerar: init, resume, sfx.*, setFlow, startMusic, stopMusic, setMuted
   ========================================================================= */
const Sound = (() => {
  let ctx = null, master = null, muted = false, music = null;
  let flowGain = null, flowFilter = null;

  function init() {
    if (ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = muted ? 0 : 0.5;
    master.connect(ctx.destination);

    // Kontinuerligt elbrum (skalas av setFlow)
    flowGain = ctx.createGain(); flowGain.gain.value = 0;
    flowFilter = ctx.createBiquadFilter(); flowFilter.type = 'lowpass'; flowFilter.frequency.value = 500;
    const o1 = ctx.createOscillator(); o1.type = 'sawtooth'; o1.frequency.value = 60;
    const o2 = ctx.createOscillator(); o2.type = 'sine'; o2.frequency.value = 120;
    o1.connect(flowFilter); o2.connect(flowFilter); flowFilter.connect(flowGain); flowGain.connect(master);
    o1.start(); o2.start();
  }
  function resume() { if (ctx && ctx.state === 'suspended') ctx.resume(); }

  function blip(freq, dur, type = 'square', vol = 0.3, slideTo = null) {
    if (!ctx || muted) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.02);
  }
  function seq(notes, step, dur, type, vol) { notes.forEach((f, i) => setTimeout(() => blip(f, dur, type, vol), i * step)); }

  const sfx = {
    click:    () => blip(440, 0.04, 'square', 0.12),
    place:    () => blip(200, 0.08, 'square', 0.22, 320),
    line:     () => blip(110, 0.13, 'sawtooth', 0.20, 580),
    erase:    () => blip(200, 0.10, 'square', 0.18, 80),
    research: () => seq([523.25, 659.25, 783.99, 1046.5], 70, 0.25, 'triangle', 0.22),
    win:      () => seq([392, 523.25, 659.25, 783.99, 1046.5], 90, 0.45, 'triangle', 0.28),
    error:    () => blip(90, 0.14, 'square', 0.15, 60),
  };

  // level 0..1 -> brummets styrka/ljusstyrka
  function setFlow(level) {
    if (!ctx || !flowGain) return;
    const t = ctx.currentTime;
    flowGain.gain.setTargetAtTime(muted ? 0 : Math.min(0.05, level * 0.05), t, 0.3);
    flowFilter.frequency.setTargetAtTime(350 + level * 500, t, 0.3);
  }

  function startMusic() {
    if (!ctx || muted || music) return;
    const now = ctx.currentTime;
    const bus = ctx.createGain(); bus.gain.value = 0; bus.connect(master);
    bus.gain.setTargetAtTime(0.13, now, 1.5);
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 800; lp.connect(bus);
    const pad = [110, 164.81, 220, 329.63].map((f, i) => {
      const o = ctx.createOscillator(); o.type = i % 2 ? 'sine' : 'triangle'; o.frequency.value = f;
      const g = ctx.createGain(); g.gain.value = 0.06; o.connect(g); g.connect(lp); o.start(); return o;
    });
    const lfo = ctx.createOscillator(); lfo.frequency.value = 0.07;
    const lfoG = ctx.createGain(); lfoG.gain.value = 280; lfo.connect(lfoG); lfoG.connect(lp.frequency); lfo.start();
    const arpNotes = [440, 523.25, 659.25, 880, 659.25, 523.25];
    let step = 0;
    const arp = setInterval(() => { if (!muted) blip(arpNotes[step++ % arpNotes.length], 0.4, 'sine', 0.045); }, 900);
    music = { bus, pad, lfo, arp };
  }
  function stopMusic() {
    if (!music) return;
    const m = music; music = null;
    try { m.bus.gain.setTargetAtTime(0, ctx.currentTime, 0.4); } catch (e) {}
    clearInterval(m.arp);
    setTimeout(() => { try { m.pad.forEach(o => o.stop()); m.lfo.stop(); } catch (e) {} }, 900);
  }

  function setMuted(m) {
    muted = m;
    if (master && ctx) master.gain.setTargetAtTime(m ? 0 : 0.5, ctx.currentTime, 0.05);
    if (m) { stopMusic(); setFlow(0); }
  }

  return { init, resume, sfx, setFlow, startMusic, stopMusic, setMuted, isMuted: () => muted };
})();
