package com.wattthef.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
